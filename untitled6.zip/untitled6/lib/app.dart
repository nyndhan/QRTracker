/**
 * Enhanced App Widget with Hybrid Architecture Support
 */
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/di/dependency_injection.dart';
import 'features/authentication/presentation/auth_bloc.dart';
import 'features/qr_management/presentation/qr_bloc.dart';
import 'features/railway_management/presentation/railway_bloc.dart';
import 'features/ai_analytics/presentation/ai_bloc.dart';
import 'features/realtime_sync/presentation/sync_bloc.dart';
import 'shared/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'app_router.dart';

class EnhancedApp extends StatelessWidget {
  const EnhancedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(create: (context) => getIt<AuthBloc>()),
        BlocProvider<QrBloc>(create: (context) => getIt<QrBloc>()),
        BlocProvider<RailwayBloc>(create: (context) => getIt<RailwayBloc>()),
        BlocProvider<AiBloc>(create: (context) => getIt<AiBloc>()),
        BlocProvider<SyncBloc>(create: (context) => getIt<SyncBloc>()),
      ],
      child: MaterialApp.router(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: EnhancedAppTheme.lightTheme,
        darkTheme: EnhancedAppTheme.darkTheme,
        themeMode: ThemeMode.system,
        routerConfig: EnhancedAppRouter.router,
      ),
    );
  }
}
