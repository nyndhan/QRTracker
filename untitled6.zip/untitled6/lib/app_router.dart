/**
 * Enhanced App Router with Go Router - All Routes Configured
 */
import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';

import 'features/authentication/presentation/login_screen.dart';
import 'features/qr_management/presentation/qr_scanner_screen.dart';
import 'features/qr_management/presentation/qr_generator_screen.dart';
import 'features/railway_management/presentation/railway_dashboard.dart';

class EnhancedAppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        name: 'home',
        builder: (context, state) => const RailwayDashboard(),
      ),
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/qr-scanner',
        name: 'qr-scanner',
        builder: (context, state) => const QrScannerScreen(),
      ),
      GoRoute(
        path: '/qr-generator',
        name: 'qr-generator',
        builder: (context, state) => const QrGeneratorScreen(),
      ),
    ],
  );
}
