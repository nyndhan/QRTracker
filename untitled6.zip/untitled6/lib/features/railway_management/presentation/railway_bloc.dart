/**
 * Railway Bloc BLoC
 */
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class RailwayBlocEvent extends Equatable {
  const RailwayBlocEvent();
  @override
  List<Object?> get props => [];
}

// States  
abstract class RailwayBlocState extends Equatable {
  const RailwayBlocState();
  @override
  List<Object?> get props => [];
}

class RailwayBlocInitial extends RailwayBlocState {}

// BLoC
class RailwayBloc extends Bloc<RailwayBlocEvent, RailwayBlocState> {
  RailwayBloc() : super(RailwayBlocInitial()) {
    // TODO: Implement Railway Bloc BLoC logic
  }
}
