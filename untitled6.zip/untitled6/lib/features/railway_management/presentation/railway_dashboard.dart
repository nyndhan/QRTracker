import 'package:flutter/material.dart';

class RailwayDashboard extends StatelessWidget {
  const RailwayDashboard({super.key}); // ✅ now you can use const

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Railway Dashboard')),
      body: const Center(child: Text('Railway Dashboard Screen')),
    );
  }
}
