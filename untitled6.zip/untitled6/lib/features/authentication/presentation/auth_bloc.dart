/**
 * Auth Bloc BLoC
 */
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class AuthBlocEvent extends Equatable {
  const AuthBlocEvent();
  @override
  List<Object?> get props => [];
}

// States  
abstract class AuthBlocState extends Equatable {
  const AuthBlocState();
  @override
  List<Object?> get props => [];
}

class AuthBlocInitial extends AuthBlocState {}

// BLoC
class AuthBloc extends Bloc<AuthBlocEvent, AuthBlocState> {
  AuthBloc() : super(AuthBlocInitial()) {
    // TODO: Implement Auth Bloc BLoC logic
  }
}
