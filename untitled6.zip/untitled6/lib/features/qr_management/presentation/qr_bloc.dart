/**
 * Qr Bloc BLoC
 */
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class QrBlocEvent extends Equatable {
  const QrBlocEvent();
  @override
  List<Object?> get props => [];
}

// States  
abstract class QrBlocState extends Equatable {
  const QrBlocState();
  @override
  List<Object?> get props => [];
}

class QrBlocInitial extends QrBlocState {}

// BLoC
class QrBloc extends Bloc<QrBlocEvent, QrBlocState> {
  QrBloc() : super(QrBlocInitial()) {
    // TODO: Implement Qr Bloc BLoC logic
  }
}
