/**
 * Ai Bloc BLoC
 */
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class AiBlocEvent extends Equatable {
  const AiBlocEvent();
  @override
  List<Object?> get props => [];
}

// States  
abstract class AiBlocState extends Equatable {
  const AiBlocState();
  @override
  List<Object?> get props => [];
}

class AiBlocInitial extends AiBlocState {}

// BLoC
class AiBloc extends Bloc<AiBlocEvent, AiBlocState> {
  AiBloc() : super(AiBlocInitial()) {
    // TODO: Implement Ai Bloc BLoC logic
  }
}
