/**
 * Sync Bloc BLoC
 */
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

// Events
abstract class SyncBlocEvent extends Equatable {
  const SyncBlocEvent();
  @override
  List<Object?> get props => [];
}

// States  
abstract class SyncBlocState extends Equatable {
  const SyncBlocState();
  @override
  List<Object?> get props => [];
}

class SyncBlocInitial extends SyncBlocState {}

// BLoC
class SyncBloc extends Bloc<SyncBlocEvent, SyncBlocState> {
  SyncBloc() : super(SyncBlocInitial()) {
    // TODO: Implement Sync Bloc BLoC logic
  }
}
