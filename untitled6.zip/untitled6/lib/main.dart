/**
 * Enhanced Railway AI QR Management System - Flutter Mobile App
 * Hybrid architecture with enhanced QR management and real-time capabilities
 * Smart India Hackathon 2025
 */

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'core/di/dependency_injection.dart';
import 'core/database/hybrid_database_service.dart';
import 'core/services/background_service.dart';
import 'core/utils/app_bloc_observer.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Initialize Hive for local storage
  await Hive.initFlutter();

  // Initialize dependency injection
  await DependencyInjection.init();

  // Initialize hybrid database (SQLite + cloud sync placeholder)
  await HybridDatabaseService.init();

  // Initialize background services (placeholder)
  await BackgroundService.init();

  // Set up BLoC observer for debugging
  Bloc.observer = AppBlocObserver();

  // Run the app
  runApp(const EnhancedRailwayQRApp());
}

class EnhancedRailwayQRApp extends StatelessWidget {
  const EnhancedRailwayQRApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return const EnhancedApp();
      },
    );
  }
}
