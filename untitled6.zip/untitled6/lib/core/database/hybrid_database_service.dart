class HybridDatabaseService {
  /// Initialize local + remote DBs (stubbed here)
  static Future<void> init() async {
    // TODO: Add your SQLite / MongoDB Realm / Hive init logic
    await Future<void>.delayed(const Duration(milliseconds: 200));
    print('HybridDatabaseService initialized');
  }
}
