import 'package:get_it/get_it.dart';

import '../../features/authentication/presentation/auth_bloc.dart';
import '../../features/qr_management/presentation/qr_bloc.dart';
import '../../features/railway_management/presentation/railway_bloc.dart';
import '../../features/ai_analytics/presentation/ai_bloc.dart';
import '../../features/realtime_sync/presentation/sync_bloc.dart';

final GetIt getIt = GetIt.instance;

class DependencyInjection {
  static Future<void> init() async {
    // Register blocs
    getIt.registerFactory<AuthBloc>(() => AuthBloc());
    getIt.registerFactory<QrBloc>(() => QrBloc());
    getIt.registerFactory<RailwayBloc>(() => RailwayBloc());
    getIt.registerFactory<AiBloc>(() => AiBloc());
    getIt.registerFactory<SyncBloc>(() => SyncBloc());

    // 👉 If you have repositories/services, register them here too
    // getIt.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl());
  }
}
