/**
 * Enhanced App Constants for Railway QR System
 */
class AppConstants {
  static const String appName = 'Railway AI QR Ultimate Enhanced';
  static const String version = '2.0.0';
  static const String buildNumber = '1';

  // Enhanced Hybrid Architecture URLs
  static const String coreApiUrl = 'http://10.0.2.2:8000/api/v1';
  static const String qrServiceUrl = 'http://10.0.2.2:3001/api';
  static const String realtimeServiceUrl = 'http://10.0.2.2:3002';
  static const String aiServiceUrl = 'http://10.0.2.2:8001';

  // Database
  static const String databaseName = 'railway_qr_enhanced.db';
  static const int databaseVersion = 2;

  // Enhanced Storage Keys
  static const String keyAuthToken = 'auth_token';
  static const String keyUserId = 'user_id';
  static const String keyUserData = 'user_data';
  static const String keyThemeMode = 'theme_mode';
  static const String keyLanguage = 'language';
  static const String keyLastSync = 'last_sync';
  static const String keyOfflineMode = 'offline_mode';

  // Enhanced Sync Configuration
  static const Duration syncInterval = Duration(minutes: 5);
  static const int maxRetries = 5;
  static const int batchSize = 100;

  // Enhanced QR Configuration
  static const int qrCodeSize = 400;
  static const String defaultErrorCorrection = 'H';
  static const int maxQrBatchSize = 1000;

  // Railway Specific Constants
  static const List<String> componentTypes = [
    'elastic_rail_clip',
    'rail_pad',
    'liner',
    'sleeper',
  ];

  static const List<String> inspectionTypes = [
    'routine',
    'detailed',
    'emergency',
    'quality_check',
  ];

  static const Map<String, int> warrantyPeriods = {
    'elastic_rail_clip': 60, // months
    'rail_pad': 48,
    'liner': 72,
    'sleeper': 300,
  };

  // Timeouts
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // Cache Configuration
  static const Duration cacheTimeout = Duration(hours: 24);
  static const int maxCacheSize = 100 * 1024 * 1024; // 100MB
}
