/**
 * MongoDB Schema for QR Analytics Collection
 */

const mongoose = require('mongoose');

const qrAnalyticsSchema = new mongoose.Schema({
  qr_id: {
    type: String,
    required: true,
    index: true
  },
  component_id: {
    type: String,
    required: true,
    index: true
  },
  component_type: {
    type: String,
    required: true,
    enum: ['elastic_rail_clip', 'rail_pad', 'liner', 'sleeper'],
    index: true
  },
  event_type: {
    type: String,
    required: true,
    enum: ['generated', 'scanned', 'printed', 'validated'],
    index: true
  },
  event_data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      index: '2dsphere'
    }
  },
  user_id: {
    type: String,
    index: true
  },
  session_id: {
    type: String,
    index: true
  },
  device_info: {
    platform: String,
    user_agent: String,
    ip_address: String,
    app_version: String
  },
  performance_metrics: {
    generation_time: Number,
    scan_time: Number,
    processing_time: Number,
    response_time: Number
  },
  quality_metrics: {
    qr_quality_score: Number,
    scan_quality_score: Number,
    validation_score: Number
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  collection: 'qr_analytics',
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
  versionKey: false
});

// Indexes for performance
qrAnalyticsSchema.index({ timestamp: -1, event_type: 1 });
qrAnalyticsSchema.index({ component_id: 1, timestamp: -1 });
qrAnalyticsSchema.index({ qr_id: 1, timestamp: -1 });
qrAnalyticsSchema.index({ user_id: 1, timestamp: -1 });

// TTL index to automatically remove old data (90 days)
qrAnalyticsSchema.index({ timestamp: 1 }, { expireAfterSeconds: 90 * 24 * 60 * 60 });

module.exports = mongoose.model('QRAnalytics', qrAnalyticsSchema);
