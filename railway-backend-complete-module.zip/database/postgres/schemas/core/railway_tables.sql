-- Railway Management System - PostgreSQL Schema
-- Smart India Hackathon 2025

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    employee_id VARCHAR(50) UNIQUE,
    phone VARCHAR(20),
    mobile VARCHAR(20),
    emergency_contact VARCHAR(20),
    address TEXT,
    department VARCHAR(100),
    designation VARCHAR(100),
    reporting_manager VARCHAR(100),
    zone VARCHAR(20),
    division VARCHAR(20),
    section VARCHAR(50),
    depot VARCHAR(100),
    role VARCHAR(20) NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin', 'supervisor', 'inspector', 'operator', 'viewer')),
    permissions TEXT[],
    access_level INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    is_superuser BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('active', 'inactive', 'suspended', 'pending')),
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP,
    password_changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    must_change_password BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    last_login_ip INET,
    login_count INTEGER DEFAULT 0,
    profile_picture_url VARCHAR(500),
    bio TEXT,
    preferences JSONB DEFAULT '{}',
    settings JSONB DEFAULT '{}',
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_of_birth DATE,
    metadata JSONB DEFAULT '{}',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tracks table
CREATE TABLE IF NOT EXISTS tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    track_code VARCHAR(50) UNIQUE NOT NULL,
    track_name VARCHAR(200) NOT NULL,
    zone VARCHAR(20) NOT NULL,
    division VARCHAR(20) NOT NULL,
    section VARCHAR(50) NOT NULL,
    gauge VARCHAR(20) DEFAULT '1435',
    track_class VARCHAR(10) NOT NULL CHECK (track_class IN ('A', 'B', 'C', 'D', 'E')),
    max_speed INTEGER,
    start_location VARCHAR(100),
    end_location VARCHAR(100),
    total_length DECIMAL(10,3),
    start_latitude DECIMAL(10,8),
    start_longitude DECIMAL(11,8),
    end_latitude DECIMAL(10,8),
    end_longitude DECIMAL(11,8),
    status VARCHAR(20) DEFAULT 'active',
    commissioned_date TIMESTAMP,
    last_inspection_date TIMESTAMP,
    next_inspection_date TIMESTAMP,
    metadata JSONB DEFAULT '{}',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id)
);

-- Railway Components table
CREATE TABLE IF NOT EXISTS railway_components (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component_id VARCHAR(50) UNIQUE NOT NULL,
    serial_number VARCHAR(100) UNIQUE NOT NULL,
    component_type VARCHAR(30) NOT NULL CHECK (component_type IN ('elastic_rail_clip', 'rail_pad', 'liner', 'sleeper')),
    manufacturer VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    batch_number VARCHAR(50),
    track_id UUID NOT NULL REFERENCES tracks(id),
    chainage DECIMAL(10,3),
    side VARCHAR(10) CHECK (side IN ('LEFT', 'RIGHT', 'CENTER')),
    installation_date TIMESTAMP NOT NULL,
    installation_crew VARCHAR(100),
    installation_method VARCHAR(50),
    specifications JSONB DEFAULT '{}',
    dimensions JSONB DEFAULT '{}',
    material VARCHAR(100),
    grade VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'maintenance', 'damaged', 'replaced', 'retired')),
    condition_score DECIMAL(5,2),
    last_inspection_date TIMESTAMP,
    next_inspection_date TIMESTAMP,
    warranty_start DATE,
    warranty_end DATE,
    warranty_provider VARCHAR(100),
    qr_code_id UUID,
    metadata JSONB DEFAULT '{}',
    notes TEXT,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id)
);

-- QR Codes table
CREATE TABLE IF NOT EXISTS qr_codes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    qr_id VARCHAR(100) UNIQUE NOT NULL,
    qr_data TEXT NOT NULL,
    qr_data_hash VARCHAR(64),
    size INTEGER DEFAULT 300,
    error_correction_level VARCHAR(1) DEFAULT 'M' CHECK (error_correction_level IN ('L', 'M', 'Q', 'H')),
    format VARCHAR(10) DEFAULT 'PNG',
    template_id UUID,
    template_version VARCHAR(20),
    component_id UUID REFERENCES railway_components(id),
    component_type VARCHAR(30),
    component_serial VARCHAR(100),
    image_url VARCHAR(500),
    image_base64 TEXT,
    image_size_bytes INTEGER,
    print_ready BOOLEAN DEFAULT FALSE,
    print_settings JSONB DEFAULT '{}',
    printed_count INTEGER DEFAULT 0,
    last_printed_at TIMESTAMP,
    printed_by UUID REFERENCES users(id),
    scan_count INTEGER DEFAULT 0,
    first_scanned_at TIMESTAMP,
    last_scanned_at TIMESTAMP,
    unique_scanners INTEGER DEFAULT 0,
    quality_score DECIMAL(3,2),
    validation_status VARCHAR(20) DEFAULT 'valid',
    validation_errors TEXT[],
    batch_id VARCHAR(100),
    generation_method VARCHAR(50) DEFAULT 'single',
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'damaged', 'replaced', 'expired')),
    activation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry_date TIMESTAMP,
    deactivation_date TIMESTAMP,
    deactivation_reason VARCHAR(200),
    installation_location JSONB,
    current_location JSONB,
    location_accuracy DECIMAL(10,2),
    metadata JSONB DEFAULT '{}',
    tags TEXT[],
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id)
);

-- Component Inspections table
CREATE TABLE IF NOT EXISTS component_inspections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    inspection_id VARCHAR(50) UNIQUE NOT NULL,
    component_id UUID NOT NULL REFERENCES railway_components(id),
    inspection_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    inspector_name VARCHAR(100) NOT NULL,
    inspection_method VARCHAR(50) DEFAULT 'visual',
    qr_scanned BOOLEAN DEFAULT FALSE,
    qr_scan_time TIMESTAMP,
    qr_scan_location JSONB,
    condition_rating VARCHAR(20) NOT NULL CHECK (condition_rating IN ('excellent', 'good', 'fair', 'poor', 'critical')),
    condition_score DECIMAL(5,2) CHECK (condition_score >= 0 AND condition_score <= 100),
    wear_level DECIMAL(5,2) CHECK (wear_level >= 0 AND wear_level <= 100),
    damage_assessment JSONB DEFAULT '{}',
    measurements JSONB DEFAULT '{}',
    tolerances_met BOOLEAN,
    out_of_spec_items TEXT[],
    action_required VARCHAR(50) NOT NULL CHECK (action_required IN ('none', 'monitor', 'repair', 'replace')),
    urgency_level VARCHAR(20) NOT NULL CHECK (urgency_level IN ('low', 'medium', 'high', 'critical')),
    recommended_action_date DATE,
    estimated_remaining_life INTEGER,
    photos TEXT[],
    inspection_report_url VARCHAR(200),
    follow_up_required BOOLEAN DEFAULT FALSE,
    follow_up_date DATE,
    corrective_actions_taken TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Vendors table
CREATE TABLE IF NOT EXISTS vendors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vendor_code VARCHAR(50) UNIQUE NOT NULL,
    vendor_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    website VARCHAR(200),
    address_line1 VARCHAR(200),
    address_line2 VARCHAR(200),
    city VARCHAR(100),
    state VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100) DEFAULT 'India',
    registration_number VARCHAR(50),
    tax_id VARCHAR(50),
    certification_details JSONB DEFAULT '{}',
    specializations TEXT[],
    railway_approved BOOLEAN DEFAULT FALSE,
    approval_date DATE,
    approval_validity DATE,
    quality_rating DECIMAL(3,2) CHECK (quality_rating >= 0 AND quality_rating <= 5),
    status VARCHAR(20) DEFAULT 'active',
    blacklisted BOOLEAN DEFAULT FALSE,
    blacklist_reason TEXT,
    delivery_performance DECIMAL(5,2),
    quality_performance DECIMAL(5,2),
    total_orders INTEGER DEFAULT 0,
    total_value DECIMAL(15,2) DEFAULT 0.0,
    metadata JSONB DEFAULT '{}',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id)
);

-- Audit Logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL CHECK (action IN ('CREATE', 'UPDATE', 'DELETE', 'VIEW')),
    old_values JSONB,
    new_values JSONB,
    changes JSONB,
    user_id UUID REFERENCES users(id),
    session_id VARCHAR(100),
    ip_address INET,
    user_agent VARCHAR(500),
    location JSONB,
    device_info JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    context JSONB DEFAULT '{}',
    notes TEXT
);

-- User Sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id VARCHAR(255) UNIQUE NOT NULL,
    user_id UUID NOT NULL REFERENCES users(id),
    refresh_token VARCHAR(500),
    access_token_jti VARCHAR(100),
    device_info JSONB DEFAULT '{}',
    user_agent VARCHAR(500),
    ip_address INET,
    location JSONB,
    platform VARCHAR(50),
    app_version VARCHAR(50),
    os_info VARCHAR(200),
    is_active BOOLEAN DEFAULT TRUE,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_count INTEGER DEFAULT 0,
    is_suspicious BOOLEAN DEFAULT FALSE,
    security_flags TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    terminated_at TIMESTAMP,
    termination_reason VARCHAR(100)
);

-- User Activities table  
CREATE TABLE IF NOT EXISTS user_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    session_id VARCHAR(255),
    activity_type VARCHAR(50) NOT NULL,
    activity_description VARCHAR(500),
    endpoint VARCHAR(200),
    method VARCHAR(10),
    status_code INTEGER,
    request_data JSONB,
    response_data JSONB,
    processing_time DECIMAL(10,3),
    ip_address INET,
    user_agent VARCHAR(500),
    location JSONB,
    device_info JSONB,
    metadata JSONB DEFAULT '{}',
    tags TEXT[],
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Permissions table
CREATE TABLE IF NOT EXISTS permissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    codename VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    category VARCHAR(50),
    module VARCHAR(50),
    resource VARCHAR(50),
    action VARCHAR(50),
    parent_permission_id UUID,
    level INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    is_system_permission BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Role Permissions table
CREATE TABLE IF NOT EXISTS role_permissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'supervisor', 'inspector', 'operator', 'viewer')),
    permission_id UUID NOT NULL REFERENCES permissions(id),
    granted BOOLEAN DEFAULT TRUE,
    granted_by UUID REFERENCES users(id),
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    conditions JSONB DEFAULT '{}',
    restrictions JSONB DEFAULT '{}',
    expires_at TIMESTAMP,
    is_temporary BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- API Keys table
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key_id VARCHAR(50) UNIQUE NOT NULL,
    key_hash VARCHAR(255) NOT NULL,
    key_name VARCHAR(200) NOT NULL,
    description TEXT,
    user_id UUID NOT NULL REFERENCES users(id),
    permissions TEXT[],
    scope TEXT[],
    usage_count INTEGER DEFAULT 0,
    last_used TIMESTAMP,
    rate_limit INTEGER DEFAULT 1000,
    is_active BOOLEAN DEFAULT TRUE,
    is_revoked BOOLEAN DEFAULT FALSE,
    revoked_at TIMESTAMP,
    revoked_by UUID REFERENCES users(id),
    revocation_reason VARCHAR(500),
    expires_at TIMESTAMP,
    auto_rotate BOOLEAN DEFAULT FALSE,
    allowed_ips INET[],
    allowed_domains TEXT[],
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_tracks_zone_division ON tracks(zone, division);
CREATE INDEX IF NOT EXISTS idx_tracks_code ON tracks(track_code);
CREATE INDEX IF NOT EXISTS idx_components_serial ON railway_components(serial_number);
CREATE INDEX IF NOT EXISTS idx_components_type ON railway_components(component_type);
CREATE INDEX IF NOT EXISTS idx_components_track ON railway_components(track_id);
CREATE INDEX IF NOT EXISTS idx_components_status ON railway_components(status);
CREATE INDEX IF NOT EXISTS idx_qr_codes_component ON qr_codes(component_id);
CREATE INDEX IF NOT EXISTS idx_qr_codes_hash ON qr_codes(qr_data_hash);
CREATE INDEX IF NOT EXISTS idx_qr_codes_status ON qr_codes(status);
CREATE INDEX IF NOT EXISTS idx_inspections_component ON component_inspections(component_id);
CREATE INDEX IF NOT EXISTS idx_inspections_date ON component_inspections(inspection_date);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_user_activities_timestamp ON user_activities(timestamp);
CREATE INDEX IF NOT EXISTS idx_user_activities_user ON user_activities(user_id);

-- GIS Indexes (if PostGIS is available)
-- CREATE INDEX IF NOT EXISTS idx_tracks_start_location ON tracks USING GIST(ST_MakePoint(start_longitude, start_latitude));
-- CREATE INDEX IF NOT EXISTS idx_tracks_end_location ON tracks USING GIST(ST_MakePoint(end_longitude, end_latitude));

-- Update triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply update triggers
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_tracks_updated_at BEFORE UPDATE ON tracks FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_railway_components_updated_at BEFORE UPDATE ON railway_components FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_qr_codes_updated_at BEFORE UPDATE ON qr_codes FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_component_inspections_updated_at BEFORE UPDATE ON component_inspections FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_vendors_updated_at BEFORE UPDATE ON vendors FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_permissions_updated_at BEFORE UPDATE ON permissions FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_role_permissions_updated_at BEFORE UPDATE ON role_permissions FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_api_keys_updated_at BEFORE UPDATE ON api_keys FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Default permissions data
INSERT INTO permissions (name, codename, description, category, module, resource, action) VALUES
('View Dashboard', 'dashboard.view', 'View main dashboard', 'dashboard', 'core', 'dashboard', 'view'),
('View Railway Data', 'railway.track.read', 'View railway track data', 'railway', 'railway', 'track', 'read'),
('Create Railway Data', 'railway.track.create', 'Create railway track data', 'railway', 'railway', 'track', 'create'),
('Update Railway Data', 'railway.track.update', 'Update railway track data', 'railway', 'railway', 'track', 'update'),
('Delete Railway Data', 'railway.track.delete', 'Delete railway track data', 'railway', 'railway', 'track', 'delete'),
('View Components', 'railway.component.read', 'View railway components', 'railway', 'railway', 'component', 'read'),
('Create Components', 'railway.component.create', 'Create railway components', 'railway', 'railway', 'component', 'create'),
('Update Components', 'railway.component.update', 'Update railway components', 'railway', 'railway', 'component', 'update'),
('Delete Components', 'railway.component.delete', 'Delete railway components', 'railway', 'railway', 'component', 'delete'),
('Bulk Component Operations', 'railway.component.bulk_create', 'Bulk create components', 'railway', 'railway', 'component', 'bulk_create'),
('View QR Codes', 'qr.read', 'View QR codes', 'qr', 'qr', 'qr', 'read'),
('Generate QR Codes', 'qr.create', 'Generate QR codes', 'qr', 'qr', 'qr', 'create'),
('Scan QR Codes', 'qr.scan', 'Scan QR codes', 'qr', 'qr', 'qr', 'scan'),
('Print QR Codes', 'qr.print', 'Print QR codes', 'qr', 'qr', 'qr', 'print'),
('Manage QR Templates', 'qr.template.manage', 'Manage QR templates', 'qr', 'qr', 'template', 'manage'),
('Create Inspections', 'railway.inspection.create', 'Create inspections', 'railway', 'railway', 'inspection', 'create'),
('View Inspections', 'railway.inspection.read', 'View inspections', 'railway', 'railway', 'inspection', 'read'),
('Update Inspections', 'railway.inspection.update', 'Update inspections', 'railway', 'railway', 'inspection', 'update'),
('View Analytics', 'railway.analytics.read', 'View analytics', 'railway', 'railway', 'analytics', 'read'),
('Manage Users', 'user.manage', 'Manage user accounts', 'admin', 'admin', 'user', 'manage'),
('System Administration', 'system.admin', 'System administration', 'admin', 'admin', 'system', 'admin')
ON CONFLICT (codename) DO NOTHING;

-- Default role permissions
INSERT INTO role_permissions (role, permission_id, granted) 
SELECT 'admin', id, TRUE FROM permissions
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role, permission_id, granted) 
SELECT 'supervisor', id, TRUE FROM permissions 
WHERE category IN ('dashboard', 'railway', 'qr') AND action != 'delete'
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role, permission_id, granted) 
SELECT 'inspector', id, TRUE FROM permissions 
WHERE codename IN ('dashboard.view', 'railway.track.read', 'railway.component.read', 'railway.component.update', 'railway.inspection.create', 'railway.inspection.read', 'railway.inspection.update', 'qr.read', 'qr.scan', 'railway.analytics.read')
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role, permission_id, granted) 
SELECT 'operator', id, TRUE FROM permissions 
WHERE codename IN ('dashboard.view', 'railway.track.read', 'railway.component.read', 'railway.inspection.read', 'qr.read', 'qr.scan')
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role, permission_id, granted) 
SELECT 'viewer', id, TRUE FROM permissions 
WHERE codename IN ('dashboard.view', 'railway.track.read', 'railway.component.read', 'railway.inspection.read', 'qr.read')
ON CONFLICT DO NOTHING;
