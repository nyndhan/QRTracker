"""
FastAPI Core Service - Main Application
Railway AI QR Management System - Smart India Hackathon 2025
"""

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import uvicorn
import logging
from prometheus_client import make_asgi_app
import time

from app.config import settings
from app.database import engine, create_tables
from app.api.routes import auth, railway, qr_core, inventory, maintenance, integration
from app.middleware.logging import setup_logging
from app.middleware.security import SecurityMiddleware
from app.middleware.rate_limit import RateLimitMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    setup_logging()
    logging.info("🚀 Starting Railway AI QR Core Service...")

    # Create database tables
    await create_tables()
    logging.info("📊 Database tables created/verified")

    yield

    # Shutdown
    logging.info("🛑 Shutting down Railway AI QR Core Service...")


# Create FastAPI app
app = FastAPI(
    title="Railway AI QR Management System - Core API",
    description="Advanced Railway Component QR Management with AI Analytics",
    version="2.0.0",
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT != "production" else None,
    lifespan=lifespan
)

# Security middleware
app.add_middleware(SecurityMiddleware)
app.add_middleware(RateLimitMiddleware)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Response-Time"],
)

# Trusted host middleware
if settings.ENVIRONMENT == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "railway-core-api",
        "version": "2.0.0",
        "timestamp": datetime.now().isoformat(),
        "database": "connected",
        "environment": settings.ENVIRONMENT
    }

# Metrics endpoint
if settings.ENABLE_METRICS:
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

# API Routes
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(railway.router, prefix="/api/v1/railway", tags=["Railway Management"])
app.include_router(qr_core.router, prefix="/api/v1/qr", tags=["QR Core Operations"])
app.include_router(inventory.router, prefix="/api/v1/inventory", tags=["Inventory Management"])
app.include_router(maintenance.router, prefix="/api/v1/maintenance", tags=["Maintenance Operations"])
app.include_router(integration.router, prefix="/api/v1/integration", tags=["External Integrations"])

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "🚂 Railway AI QR Management System - Core API",
        "version": "2.0.0",
        "docs": "/docs" if settings.ENVIRONMENT != "production" else "disabled",
        "health": "/health",
        "metrics": "/metrics" if settings.ENABLE_METRICS else "disabled"
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logging.error(f"Global exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "message": "Internal server error",
            "error_id": f"ERR_{int(time.time())}",
            "timestamp": datetime.now().isoformat()
        }
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.ENVIRONMENT == "development",
        workers=settings.WORKERS if settings.ENVIRONMENT == "production" else 1,
        access_log=True,
        log_config={
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": "[%(asctime)s] %(levelname)s in %(module)s: %(message)s",
                },
            },
            "handlers": {
                "default": {
                    "formatter": "default",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout",
                },
            },
            "root": {
                "level": "INFO",
                "handlers": ["default"],
            },
        }
    )
