"""
Railway-specific utility functions
"""

import re
import hashlib
from typing import Dict, Any, Optional
from datetime import datetime
import uuid


def generate_component_id(component_type: str, manufacturer: str) -> str:
    """Generate unique component ID"""
    type_codes = {
        "elastic_rail_clip": "ERC",
        "rail_pad": "RPD", 
        "liner": "LNR",
        "sleeper": "SLP"
    }

    type_code = type_codes.get(component_type, "UNK")
    mfg_code = manufacturer[:3].upper() if manufacturer else "UNK"
    timestamp = datetime.now().strftime("%y%m%d%H%M")
    random_suffix = str(uuid.uuid4())[:6].upper()

    return f"{type_code}-{mfg_code}-{timestamp}-{random_suffix}"


def validate_track_code(track_code: str) -> bool:
    """Validate Indian Railways track code format"""
    # Pattern: ZONE/DIVISION/SECTION/TRACK_NUMBER
    pattern = r'^[A-Z]{2,4}/[A-Z]{2,4}/[A-Z0-9]{2,6}/[A-Z0-9]{2,8}$'
    return bool(re.match(pattern, track_code.upper()))


def calculate_component_health(condition_data: Dict[str, Any], component_type: str) -> float:
    """Calculate component health score based on condition data"""
    base_score = 100.0

    # Common deductions
    if condition_data.get("wear_level"):
        wear_level = float(condition_data["wear_level"])
        base_score -= (wear_level * 0.8)  # 0-80% deduction based on wear

    if condition_data.get("damage_assessment"):
        damage = condition_data["damage_assessment"]
        if isinstance(damage, dict):
            # Deduct based on damage severity
            severity_multipliers = {
                "minor": 5,
                "moderate": 15,
                "major": 30,
                "critical": 50
            }

            for damage_type, severity in damage.items():
                if severity in severity_multipliers:
                    base_score -= severity_multipliers[severity]

    # Component-specific calculations
    if component_type == "elastic_rail_clip":
        base_score = calculate_rail_clip_health(base_score, condition_data)
    elif component_type == "rail_pad":
        base_score = calculate_rail_pad_health(base_score, condition_data)
    elif component_type == "liner":
        base_score = calculate_liner_health(base_score, condition_data)
    elif component_type == "sleeper":
        base_score = calculate_sleeper_health(base_score, condition_data)

    # Ensure score is within bounds
    return max(0.0, min(100.0, base_score))


def calculate_rail_clip_health(base_score: float, condition_data: Dict[str, Any]) -> float:
    """Calculate health score specific to elastic rail clips"""
    # Check for spring tension
    if condition_data.get("spring_tension"):
        tension = float(condition_data["spring_tension"])
        if tension < 80:  # Below 80% tension
            base_score -= (100 - tension) * 0.5

    # Check for cracks
    if condition_data.get("cracks_detected"):
        crack_count = int(condition_data.get("crack_count", 0))
        base_score -= crack_count * 10

    # Check for corrosion
    if condition_data.get("corrosion_level"):
        corrosion = condition_data["corrosion_level"]
        corrosion_deductions = {
            "none": 0,
            "light": 5,
            "moderate": 15,
            "heavy": 30,
            "severe": 50
        }
        base_score -= corrosion_deductions.get(corrosion, 0)

    return base_score


def calculate_rail_pad_health(base_score: float, condition_data: Dict[str, Any]) -> float:
    """Calculate health score specific to rail pads"""
    # Check for compression set
    if condition_data.get("compression_set"):
        compression = float(condition_data["compression_set"])
        if compression > 20:  # Above 20% compression set
            base_score -= (compression - 20) * 2

    # Check for cuts or tears
    if condition_data.get("cuts_or_tears"):
        cut_count = int(condition_data.get("cut_count", 0))
        base_score -= cut_count * 8

    # Check for oil contamination
    if condition_data.get("oil_contamination"):
        contamination_level = condition_data["oil_contamination"]
        contamination_deductions = {
            "none": 0,
            "light": 3,
            "moderate": 8,
            "heavy": 20,
            "severe": 40
        }
        base_score -= contamination_deductions.get(contamination_level, 0)

    return base_score


def calculate_liner_health(base_score: float, condition_data: Dict[str, Any]) -> float:
    """Calculate health score specific to liners"""
    # Check for thickness reduction
    if condition_data.get("thickness_reduction"):
        reduction = float(condition_data["thickness_reduction"])
        base_score -= reduction * 3  # 3 points per % reduction

    # Check for delamination
    if condition_data.get("delamination"):
        delamination_area = float(condition_data.get("delamination_area", 0))
        base_score -= delamination_area * 5  # 5 points per % area

    # Check for hardness changes
    if condition_data.get("hardness_change"):
        hardness_change = abs(float(condition_data["hardness_change"]))
        base_score -= hardness_change * 2

    return base_score


def calculate_sleeper_health(base_score: float, condition_data: Dict[str, Any]) -> float:
    """Calculate health score specific to sleepers"""
    # Check for cracks
    if condition_data.get("crack_analysis"):
        cracks = condition_data["crack_analysis"]
        if isinstance(cracks, dict):
            crack_length = float(cracks.get("total_length", 0))
            crack_width = float(cracks.get("max_width", 0))
            base_score -= crack_length * 2 + crack_width * 10

    # Check for spalling
    if condition_data.get("spalling"):
        spalling_area = float(condition_data.get("spalling_area", 0))
        base_score -= spalling_area * 3

    # Check for reinforcement exposure
    if condition_data.get("reinforcement_exposed"):
        exposure_count = int(condition_data.get("exposure_count", 0))
        base_score -= exposure_count * 15

    return base_score


def format_railway_location(zone: str, division: str, section: str, chainage: float) -> str:
    """Format railway location string"""
    return f"{zone.upper()}/{division.upper()}/{section.upper()}/KM-{chainage:.3f}"


def parse_railway_location(location_string: str) -> Dict[str, Any]:
    """Parse railway location string"""
    try:
        parts = location_string.split("/")
        if len(parts) >= 4:
            km_part = parts[3]
            chainage = float(km_part.replace("KM-", ""))

            return {
                "zone": parts[0],
                "division": parts[1], 
                "section": parts[2],
                "chainage": chainage
            }
    except:
        pass

    return {}


def calculate_distance_between_chainages(chainage1: float, chainage2: float) -> float:
    """Calculate distance between two chainages in kilometers"""
    return abs(chainage2 - chainage1)


def validate_component_serial_number(serial_number: str, component_type: str) -> bool:
    """Validate component serial number format"""
    if not serial_number or len(serial_number) < 6:
        return False

    # Basic validation - alphanumeric with dashes/dots allowed
    pattern = r'^[A-Z0-9.\-]{6,50}$'
    return bool(re.match(pattern, serial_number.upper()))


def generate_inspection_id(component_id: str, inspection_type: str) -> str:
    """Generate unique inspection ID"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    comp_suffix = component_id[-6:] if len(component_id) >= 6 else component_id
    type_code = inspection_type[:3].upper()

    return f"INS-{type_code}-{timestamp}-{comp_suffix}"


def calculate_next_inspection_date(current_condition_score: float, component_type: str, 
                                 last_inspection_date: datetime) -> datetime:
    """Calculate next inspection date based on condition and component type"""
    base_intervals = {
        "elastic_rail_clip": 90,  # 3 months
        "rail_pad": 120,         # 4 months  
        "liner": 180,            # 6 months
        "sleeper": 365           # 12 months
    }

    base_days = base_intervals.get(component_type, 90)

    # Adjust based on condition score
    if current_condition_score >= 90:
        multiplier = 1.0
    elif current_condition_score >= 80:
        multiplier = 0.8
    elif current_condition_score >= 70:
        multiplier = 0.6
    elif current_condition_score >= 60:
        multiplier = 0.4
    else:
        multiplier = 0.2

    adjusted_days = int(base_days * multiplier)
    return last_inspection_date + timedelta(days=adjusted_days)


def validate_qr_data_integrity(qr_data: str) -> bool:
    """Validate QR code data integrity"""
    try:
        import json
        data = json.loads(qr_data)

        # Required fields
        required_fields = ["component_id", "serial_number", "component_type", "track_id"]

        for field in required_fields:
            if field not in data or not data[field]:
                return False

        return True

    except json.JSONDecodeError:
        return False
    except Exception:
        return False


def generate_component_hash(component_data: Dict[str, Any]) -> str:
    """Generate hash for component data integrity"""
    # Create a consistent string representation
    hash_data = {
        "component_id": component_data.get("component_id", ""),
        "serial_number": component_data.get("serial_number", ""),
        "component_type": component_data.get("component_type", ""),
        "manufacturer": component_data.get("manufacturer", ""),
        "installation_date": component_data.get("installation_date", "").isoformat() if isinstance(component_data.get("installation_date"), datetime) else str(component_data.get("installation_date", ""))
    }

    hash_string = json.dumps(hash_data, sort_keys=True)
    return hashlib.sha256(hash_string.encode()).hexdigest()[:16]


def format_inspection_report(inspection_data: Dict[str, Any]) -> str:
    """Format inspection data into readable report"""
    report_lines = [
        f"RAILWAY COMPONENT INSPECTION REPORT",
        f"{'='*50}",
        f"Inspection ID: {inspection_data.get('inspection_id', 'N/A')}",
        f"Date: {inspection_data.get('inspection_date', 'N/A')}",
        f"Inspector: {inspection_data.get('inspector_name', 'N/A')}",
        f"",
        f"COMPONENT DETAILS:",
        f"Component ID: {inspection_data.get('component_id', 'N/A')}",
        f"Serial Number: {inspection_data.get('serial_number', 'N/A')}",
        f"Type: {inspection_data.get('component_type', 'N/A')}",
        f"",
        f"INSPECTION RESULTS:",
        f"Condition Rating: {inspection_data.get('condition_rating', 'N/A')}",
        f"Condition Score: {inspection_data.get('condition_score', 'N/A')}/100",
        f"Wear Level: {inspection_data.get('wear_level', 'N/A')}%",
        f"",
        f"ACTION REQUIRED: {inspection_data.get('action_required', 'N/A')}",
        f"Urgency: {inspection_data.get('urgency_level', 'N/A')}",
        f"",
        f"RECOMMENDATIONS:",
        f"{inspection_data.get('recommendations', 'None')}"
    ]

    return "
".join(report_lines)


# Railway zone and division mappings
RAILWAY_ZONES = {
    "CR": "Central Railway",
    "ER": "Eastern Railway", 
    "ECR": "East Central Railway",
    "ECOR": "East Coast Railway",
    "NR": "Northern Railway",
    "NCR": "North Central Railway",
    "NFR": "Northeast Frontier Railway",
    "NWR": "North Western Railway",
    "SR": "Southern Railway",
    "SCR": "South Central Railway",
    "SECR": "South East Central Railway",
    "SER": "South Eastern Railway",
    "SWR": "South Western Railway",
    "WR": "Western Railway",
    "WCR": "West Central Railway",
    "NER": "North Eastern Railway"
}


def get_zone_full_name(zone_code: str) -> str:
    """Get full name of railway zone"""
    return RAILWAY_ZONES.get(zone_code.upper(), zone_code)


def validate_railway_coordinates(latitude: float, longitude: float) -> bool:
    """Validate coordinates are within India"""
    # India bounding box (approximate)
    if not (6.0 <= latitude <= 37.0):
        return False
    if not (68.0 <= longitude <= 97.0):
        return False
    return True
