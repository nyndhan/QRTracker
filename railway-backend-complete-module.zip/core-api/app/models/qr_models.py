"""
QR Code Models - PostgreSQL ORM Models
"""

from sqlalchemy import Column, Integer, String, DateTime, Float, Boolean, Text, ForeignKey, JSON, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from datetime import datetime
import uuid
import enum

from app.database import Base


class QRCodeStatus(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive" 
    DAMAGED = "damaged"
    REPLACED = "replaced"
    EXPIRED = "expired"


class QRTemplate(Base):
    __tablename__ = "qr_templates"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    template_name = Column(String(100), unique=True, nullable=False)
    display_name = Column(String(200), nullable=False)

    # Template details
    description = Column(Text)
    category = Column(String(50), default="custom")
    component_types = Column(ARRAY(String))  # Applicable component types

    # Template configuration
    settings = Column(JSON)  # Size, colors, error correction, etc.
    customization_options = Column(JSON)  # Available customizations
    preview_image_url = Column(String(500))

    # Usage statistics
    usage_count = Column(Integer, default=0)
    last_used = Column(DateTime)

    # Status
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)
    is_system_template = Column(Boolean, default=False)

    # Version control
    version = Column(String(20), default="1.0")
    parent_template_id = Column(UUID(as_uuid=True), ForeignKey("qr_templates.id"))

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Relationships
    qr_codes = relationship("QRCode", back_populates="template")
    parent_template = relationship("QRTemplate", remote_side=[id])


class QRCode(Base):
    __tablename__ = "qr_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    qr_id = Column(String(100), unique=True, nullable=False, index=True)

    # QR Code content
    qr_data = Column(Text, nullable=False)  # JSON string with component data
    qr_data_hash = Column(String(64), index=True)  # SHA256 hash for quick lookup

    # QR Code properties
    size = Column(Integer, default=300)
    error_correction_level = Column(String(1), default="M")  # L, M, Q, H
    format = Column(String(10), default="PNG")

    # Template information
    template_id = Column(UUID(as_uuid=True), ForeignKey("qr_templates.id"))
    template_version = Column(String(20))

    # Component association
    component_id = Column(UUID(as_uuid=True), ForeignKey("railway_components.id"), index=True)
    component_type = Column(String(50), index=True)
    component_serial = Column(String(100), index=True)

    # QR Image storage
    image_url = Column(String(500))  # URL to QR image
    image_base64 = Column(Text)  # Base64 encoded image (for offline)
    image_size_bytes = Column(Integer)

    # Print information
    print_ready = Column(Boolean, default=False)
    print_settings = Column(JSON)  # Print configuration
    printed_count = Column(Integer, default=0)
    last_printed_at = Column(DateTime)
    printed_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Usage statistics
    scan_count = Column(Integer, default=0)
    first_scanned_at = Column(DateTime)
    last_scanned_at = Column(DateTime)
    unique_scanners = Column(Integer, default=0)

    # Quality metrics
    quality_score = Column(Float)  # 0-1 quality score
    validation_status = Column(String(20), default="valid")
    validation_errors = Column(ARRAY(String))

    # Batch information
    batch_id = Column(String(100), index=True)
    generation_method = Column(String(50), default="single")  # single, batch, bulk

    # Status and lifecycle
    status = Column(SQLEnum(QRCodeStatus), default=QRCodeStatus.ACTIVE, index=True)
    activation_date = Column(DateTime, default=datetime.utcnow)
    expiry_date = Column(DateTime)
    deactivation_date = Column(DateTime)
    deactivation_reason = Column(String(200))

    # Location tracking
    installation_location = Column(JSON)  # GPS coordinates
    current_location = Column(JSON)  # Current GPS coordinates
    location_accuracy = Column(Float)  # GPS accuracy in meters

    # Additional metadata
    metadata = Column(JSON)
    tags = Column(ARRAY(String))
    notes = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Relationships
    template = relationship("QRTemplate", back_populates="qr_codes")
    component = relationship("RailwayComponent", back_populates="qr_code")
    scans = relationship("QRScan", back_populates="qr_code")
    print_jobs = relationship("QRPrintJob", back_populates="qr_code")


class QRScan(Base):
    __tablename__ = "qr_scans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scan_id = Column(String(100), unique=True, nullable=False)

    # QR Code and user
    qr_code_id = Column(UUID(as_uuid=True), ForeignKey("qr_codes.id"), nullable=False, index=True)
    scanned_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)

    # Scan details
    scan_timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    scan_method = Column(String(50), default="mobile")  # mobile, web, scanner
    device_info = Column(JSON)
    app_version = Column(String(50))

    # Location information
    scan_location = Column(JSON)  # GPS coordinates
    location_accuracy = Column(Float)
    address = Column(String(500))

    # Scan context
    scan_purpose = Column(String(100))  # inspection, maintenance, verification, etc.
    operation_context = Column(JSON)  # Additional context data
    session_id = Column(String(100))

    # Validation results
    validation_status = Column(String(20), default="valid")
    validation_errors = Column(ARRAY(String))
    data_integrity_check = Column(Boolean, default=True)

    # Performance metrics
    scan_duration = Column(Float)  # Time taken to scan in seconds
    processing_time = Column(Float)  # Server processing time
    response_time = Column(Float)  # Total response time

    # Network information
    network_type = Column(String(20))  # wifi, cellular, offline
    network_strength = Column(Integer)  # Signal strength
    sync_status = Column(String(20), default="synced")  # synced, pending, failed

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)

    # Relationships
    qr_code = relationship("QRCode", back_populates="scans")
    user = relationship("User", foreign_keys=[scanned_by])


class QRBatch(Base):
    __tablename__ = "qr_batches"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    batch_id = Column(String(100), unique=True, nullable=False, index=True)
    batch_name = Column(String(200), nullable=False)

    # Batch details
    description = Column(Text)
    template_id = Column(UUID(as_uuid=True), ForeignKey("qr_templates.id"))
    component_type = Column(String(50))

    # Processing information
    total_items = Column(Integer, nullable=False)
    processed_items = Column(Integer, default=0)
    successful_items = Column(Integer, default=0)
    failed_items = Column(Integer, default=0)

    # Status tracking
    status = Column(String(20), default="pending")  # pending, processing, completed, failed, cancelled
    progress_percentage = Column(Float, default=0.0)

    # Processing times
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    estimated_completion = Column(DateTime)
    processing_duration = Column(Float)  # seconds

    # Configuration
    batch_settings = Column(JSON)
    qr_settings = Column(JSON)

    # Results
    output_format = Column(String(20), default="zip")
    output_url = Column(String(500))
    output_size_bytes = Column(Integer)

    # Error tracking
    error_summary = Column(JSON)
    error_details = Column(Text)
    retry_count = Column(Integer, default=0)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))


class QRPrintJob(Base):
    __tablename__ = "qr_print_jobs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(String(100), unique=True, nullable=False)
    job_name = Column(String(200), nullable=False)

    # Print job details
    print_type = Column(String(50), default="single")  # single, batch, bulk
    layout = Column(String(50), default="standard")  # standard, compact, detailed
    paper_size = Column(String(20), default="A4")
    orientation = Column(String(20), default="portrait")

    # QR Codes to print
    qr_code_ids = Column(ARRAY(UUID))  # Array of QR code IDs
    qr_codes_count = Column(Integer)

    # Print settings
    print_settings = Column(JSON)
    include_metadata = Column(Boolean, default=True)
    include_component_info = Column(Boolean, default=True)
    include_qr_info = Column(Boolean, default=False)

    # Quality settings
    resolution = Column(Integer, default=300)  # DPI
    color_mode = Column(String(20), default="color")  # color, grayscale, bw

    # Status tracking
    status = Column(String(20), default="pending")  # pending, processing, ready, printed, failed
    copies_requested = Column(Integer, default=1)
    copies_printed = Column(Integer, default=0)

    # File generation
    pdf_url = Column(String(500))
    pdf_size_bytes = Column(Integer)
    generation_time = Column(Float)  # seconds

    # Printer information
    printer_name = Column(String(200))
    printed_at = Column(DateTime)
    print_duration = Column(Float)  # seconds

    # Error handling
    error_message = Column(Text)
    retry_count = Column(Integer, default=0)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Relationships
    qr_code = relationship("QRCode", back_populates="print_jobs", foreign_keys="QRPrintJob.qr_code_ids")
