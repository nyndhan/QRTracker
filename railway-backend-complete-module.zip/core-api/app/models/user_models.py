"""
User and Authentication Models
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, JSON, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from datetime import datetime
import uuid
import enum

from app.database import Base


class UserRole(enum.Enum):
    ADMIN = "admin"
    SUPERVISOR = "supervisor"
    INSPECTOR = "inspector"
    OPERATOR = "operator"
    VIEWER = "viewer"


class UserStatus(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING = "pending"


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Basic information
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)

    # Personal information
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    full_name = Column(String(200), nullable=False)
    employee_id = Column(String(50), unique=True, index=True)

    # Contact information
    phone = Column(String(20))
    mobile = Column(String(20))
    emergency_contact = Column(String(20))
    address = Column(Text)

    # Work information
    department = Column(String(100))
    designation = Column(String(100))
    reporting_manager = Column(String(100))

    # Railway specific
    zone = Column(String(20))  # Railway zone
    division = Column(String(20))  # Railway division
    section = Column(String(50))  # Railway section
    depot = Column(String(100))  # Home depot/station

    # Role and permissions
    role = Column(SQLEnum(UserRole), nullable=False, default=UserRole.VIEWER, index=True)
    permissions = Column(ARRAY(String))  # Specific permissions
    access_level = Column(Integer, default=1)  # 1-5 access levels

    # Authentication
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    is_superuser = Column(Boolean, default=False)
    status = Column(SQLEnum(UserStatus), default=UserStatus.PENDING)

    # Security
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)
    password_changed_at = Column(DateTime, default=datetime.utcnow)
    must_change_password = Column(Boolean, default=True)

    # Login tracking
    last_login = Column(DateTime)
    last_login_ip = Column(String(45))  # IPv6 compatible
    login_count = Column(Integer, default=0)

    # Profile
    profile_picture_url = Column(String(500))
    bio = Column(Text)
    preferences = Column(JSON)  # User preferences
    settings = Column(JSON)  # App settings

    # Dates
    date_joined = Column(DateTime, default=datetime.utcnow)
    date_of_birth = Column(DateTime)

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    created_qr_codes = relationship("QRCode", foreign_keys="QRCode.created_by", back_populates="creator")
    scanned_qr_codes = relationship("QRScan", back_populates="user")
    sessions = relationship("UserSession", back_populates="user")


class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(String(255), unique=True, nullable=False, index=True)

    # User and token information
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    refresh_token = Column(String(500))
    access_token_jti = Column(String(100))  # JWT ID for access token

    # Session details
    device_info = Column(JSON)  # Device information
    user_agent = Column(String(500))
    ip_address = Column(String(45))
    location = Column(JSON)  # Geographic location

    # Platform information
    platform = Column(String(50))  # web, mobile, api
    app_version = Column(String(50))
    os_info = Column(String(200))

    # Status and tracking
    is_active = Column(Boolean, default=True)
    last_activity = Column(DateTime, default=datetime.utcnow)
    activity_count = Column(Integer, default=0)

    # Security
    is_suspicious = Column(Boolean, default=False)
    security_flags = Column(ARRAY(String))

    # Session lifecycle
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    terminated_at = Column(DateTime)
    termination_reason = Column(String(100))

    # Relationships
    user = relationship("User", back_populates="sessions")


class UserActivity(Base):
    __tablename__ = "user_activities"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # User and session
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    session_id = Column(String(255), index=True)

    # Activity details
    activity_type = Column(String(50), nullable=False, index=True)  # login, logout, qr_scan, etc.
    activity_description = Column(String(500))

    # Context
    endpoint = Column(String(200))  # API endpoint
    method = Column(String(10))  # HTTP method
    status_code = Column(Integer)

    # Request information
    request_data = Column(JSON)
    response_data = Column(JSON)
    processing_time = Column(Float)  # milliseconds

    # Location and device
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    location = Column(JSON)
    device_info = Column(JSON)

    # Additional context
    metadata = Column(JSON)
    tags = Column(ARRAY(String))

    # Timestamp
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)


class Permission(Base):
    __tablename__ = "permissions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Permission details
    name = Column(String(100), unique=True, nullable=False)
    codename = Column(String(100), unique=True, nullable=False)
    description = Column(Text)

    # Categorization
    category = Column(String(50))  # qr_management, railway_management, etc.
    module = Column(String(50))
    resource = Column(String(50))
    action = Column(String(50))  # create, read, update, delete, execute

    # Hierarchy
    parent_permission_id = Column(UUID(as_uuid=True))
    level = Column(Integer, default=1)

    # Status
    is_active = Column(Boolean, default=True)
    is_system_permission = Column(Boolean, default=False)

    # Additional data
    metadata = Column(JSON)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class RolePermission(Base):
    __tablename__ = "role_permissions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Role and permission mapping
    role = Column(SQLEnum(UserRole), nullable=False, index=True)
    permission_id = Column(UUID(as_uuid=True), nullable=False, index=True)

    # Grant details
    granted = Column(Boolean, default=True)
    granted_by = Column(UUID(as_uuid=True))
    granted_at = Column(DateTime, default=datetime.utcnow)

    # Conditions and restrictions
    conditions = Column(JSON)  # Additional conditions for permission
    restrictions = Column(JSON)  # Restrictions on permission usage

    # Expiry
    expires_at = Column(DateTime)
    is_temporary = Column(Boolean, default=False)

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class APIKey(Base):
    __tablename__ = "api_keys"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # API Key details
    key_id = Column(String(50), unique=True, nullable=False, index=True)
    key_hash = Column(String(255), nullable=False)  # Hashed API key
    key_name = Column(String(200), nullable=False)
    description = Column(Text)

    # Owner
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)

    # Permissions and scope
    permissions = Column(ARRAY(String))
    scope = Column(ARRAY(String))  # API endpoints accessible

    # Usage tracking
    usage_count = Column(Integer, default=0)
    last_used = Column(DateTime)
    rate_limit = Column(Integer, default=1000)  # requests per hour

    # Status
    is_active = Column(Boolean, default=True)
    is_revoked = Column(Boolean, default=False)
    revoked_at = Column(DateTime)
    revoked_by = Column(UUID(as_uuid=True))
    revocation_reason = Column(String(500))

    # Expiry
    expires_at = Column(DateTime)
    auto_rotate = Column(Boolean, default=False)

    # Security
    allowed_ips = Column(ARRAY(String))
    allowed_domains = Column(ARRAY(String))

    # Additional data
    metadata = Column(JSON)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
