"""
Railway Models - PostgreSQL ORM Models
"""

from sqlalchemy import Column, Integer, String, DateTime, Float, Boolean, Text, ForeignKey, JSON, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from datetime import datetime
import uuid
import enum

from app.database import Base


class ComponentType(enum.Enum):
    ELASTIC_RAIL_CLIP = "elastic_rail_clip"
    RAIL_PAD = "rail_pad"
    LINER = "liner"
    SLEEPER = "sleeper"


class ComponentStatus(enum.Enum):
    ACTIVE = "active"
    MAINTENANCE = "maintenance"
    DAMAGED = "damaged"
    REPLACED = "replaced"
    RETIRED = "retired"


class Track(Base):
    __tablename__ = "tracks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    track_code = Column(String(50), unique=True, nullable=False, index=True)
    track_name = Column(String(200), nullable=False)

    # Location details
    zone = Column(String(20), nullable=False, index=True)
    division = Column(String(20), nullable=False, index=True)
    section = Column(String(50), nullable=False)

    # Track specifications
    gauge = Column(String(20), default="1435")  # Standard gauge in mm
    track_class = Column(String(10), nullable=False)  # A, B, C, D, E
    max_speed = Column(Integer)  # km/h

    # Geographic data
    start_location = Column(String(100))
    end_location = Column(String(100))
    total_length = Column(Float)  # in kilometers

    # Coordinates
    start_latitude = Column(Float)
    start_longitude = Column(Float)
    end_latitude = Column(Float)
    end_longitude = Column(Float)

    # Status and metadata
    status = Column(String(20), default="active")
    commissioned_date = Column(DateTime)
    last_inspection_date = Column(DateTime)
    next_inspection_date = Column(DateTime)

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Relationships
    components = relationship("RailwayComponent", back_populates="track")
    inspections = relationship("TrackInspection", back_populates="track")


class RailwayComponent(Base):
    __tablename__ = "railway_components"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    component_id = Column(String(50), unique=True, nullable=False, index=True)
    serial_number = Column(String(100), unique=True, nullable=False, index=True)

    # Component details
    component_type = Column(SQLEnum(ComponentType), nullable=False, index=True)
    manufacturer = Column(String(100), nullable=False)
    model = Column(String(100))
    batch_number = Column(String(50))

    # Location
    track_id = Column(UUID(as_uuid=True), ForeignKey("tracks.id"), nullable=False, index=True)
    chainage = Column(Float)  # Position on track in kilometers
    side = Column(String(10))  # LEFT, RIGHT, CENTER

    # Installation details
    installation_date = Column(DateTime, nullable=False)
    installation_crew = Column(String(100))
    installation_method = Column(String(50))

    # Specifications
    specifications = Column(JSON)  # Technical specifications
    dimensions = Column(JSON)  # Width, height, length, weight
    material = Column(String(100))
    grade = Column(String(20))

    # Status and condition
    status = Column(SQLEnum(ComponentStatus), default=ComponentStatus.ACTIVE, index=True)
    condition_score = Column(Float)  # 0-100 score
    last_inspection_date = Column(DateTime)
    next_inspection_date = Column(DateTime)

    # Warranty information
    warranty_start = Column(DateTime)
    warranty_end = Column(DateTime)
    warranty_provider = Column(String(100))

    # QR Code association
    qr_code_id = Column(UUID(as_uuid=True), ForeignKey("qr_codes.id"))

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)
    tags = Column(ARRAY(String))

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))

    # Relationships
    track = relationship("Track", back_populates="components")
    qr_code = relationship("QRCode", back_populates="component")
    maintenance_records = relationship("MaintenanceRecord", back_populates="component")
    inspections = relationship("ComponentInspection", back_populates="component")


class TrackInspection(Base):
    __tablename__ = "track_inspections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(String(50), unique=True, nullable=False)

    # Inspection details
    track_id = Column(UUID(as_uuid=True), ForeignKey("tracks.id"), nullable=False)
    inspection_type = Column(String(50), nullable=False)  # routine, special, emergency
    inspection_date = Column(DateTime, nullable=False)
    inspector_name = Column(String(100), nullable=False)
    inspector_id = Column(String(50))

    # Inspection scope
    start_chainage = Column(Float)
    end_chainage = Column(Float)
    sections_inspected = Column(ARRAY(String))

    # Findings
    overall_condition = Column(String(20))  # excellent, good, fair, poor
    condition_score = Column(Float)  # 0-100
    defects_found = Column(JSON)
    recommendations = Column(Text)

    # Actions required
    immediate_actions = Column(JSON)
    planned_maintenance = Column(JSON)
    next_inspection_date = Column(DateTime)

    # Documentation
    photos = Column(ARRAY(String))  # Photo URLs
    documents = Column(ARRAY(String))  # Document URLs
    gps_coordinates = Column(JSON)

    # Status
    status = Column(String(20), default="completed")
    approved_by = Column(String(100))
    approved_date = Column(DateTime)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    track = relationship("Track", back_populates="inspections")


class ComponentInspection(Base):
    __tablename__ = "component_inspections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(String(50), unique=True, nullable=False)

    # Component and inspection details
    component_id = Column(UUID(as_uuid=True), ForeignKey("railway_components.id"), nullable=False)
    inspection_date = Column(DateTime, nullable=False)
    inspector_name = Column(String(100), nullable=False)
    inspection_method = Column(String(50))  # visual, ultrasonic, magnetic, etc.

    # QR Code scan information
    qr_scanned = Column(Boolean, default=False)
    qr_scan_time = Column(DateTime)
    qr_scan_location = Column(JSON)  # lat, lng

    # Inspection results
    condition_rating = Column(String(20))  # excellent, good, fair, poor, critical
    condition_score = Column(Float)  # 0-100
    wear_level = Column(Float)  # 0-100%
    damage_assessment = Column(JSON)

    # Measurements
    measurements = Column(JSON)  # Various measurements
    tolerances_met = Column(Boolean)
    out_of_spec_items = Column(JSON)

    # Actions and recommendations
    action_required = Column(String(50))  # none, monitor, repair, replace
    urgency_level = Column(String(20))  # low, medium, high, critical
    recommended_action_date = Column(DateTime)
    estimated_remaining_life = Column(Integer)  # days

    # Documentation
    photos = Column(ARRAY(String))
    inspection_report_url = Column(String(200))

    # Follow-up
    follow_up_required = Column(Boolean, default=False)
    follow_up_date = Column(DateTime)
    corrective_actions_taken = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    component = relationship("RailwayComponent", back_populates="inspections")


class Vendor(Base):
    __tablename__ = "vendors"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    vendor_code = Column(String(50), unique=True, nullable=False)
    vendor_name = Column(String(200), nullable=False)

    # Contact information
    contact_person = Column(String(100))
    email = Column(String(100))
    phone = Column(String(20))
    website = Column(String(200))

    # Address
    address_line1 = Column(String(200))
    address_line2 = Column(String(200))
    city = Column(String(100))
    state = Column(String(100))
    postal_code = Column(String(20))
    country = Column(String(100), default="India")

    # Business details
    registration_number = Column(String(50))
    tax_id = Column(String(50))
    certification_details = Column(JSON)
    specializations = Column(ARRAY(String))

    # Railway specific
    railway_approved = Column(Boolean, default=False)
    approval_date = Column(DateTime)
    approval_validity = Column(DateTime)
    quality_rating = Column(Float)  # 0-5 stars

    # Status
    status = Column(String(20), default="active")
    blacklisted = Column(Boolean, default=False)
    blacklist_reason = Column(Text)

    # Performance metrics
    delivery_performance = Column(Float)  # percentage
    quality_performance = Column(Float)  # percentage
    total_orders = Column(Integer, default=0)
    total_value = Column(Float, default=0.0)

    # Additional data
    metadata = Column(JSON)
    notes = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))


# Audit trail
class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Entity information
    entity_type = Column(String(50), nullable=False, index=True)
    entity_id = Column(UUID(as_uuid=True), nullable=False, index=True)

    # Action details
    action = Column(String(50), nullable=False)  # CREATE, UPDATE, DELETE, VIEW
    old_values = Column(JSON)
    new_values = Column(JSON)
    changes = Column(JSON)  # Detailed changes

    # User and session
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), index=True)
    session_id = Column(String(100))
    ip_address = Column(String(50))
    user_agent = Column(String(500))

    # Location and device
    location = Column(JSON)  # lat, lng
    device_info = Column(JSON)

    # Timestamp
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    # Additional context
    context = Column(JSON)
    notes = Column(Text)
