"""
Security Middleware for Railway AI QR System
"""

from fastapi import Request, Response
from fastapi.responses import JSONResponse
import time
import hashlib
import hmac
import logging
from typing import Dict, Any
import jwt

logger = logging.getLogger(__name__)


class SecurityMiddleware:
    """Security middleware for request validation and protection"""

    def __init__(self, secret_key: str):
        self.secret_key = secret_key
        self.blocked_ips = set()
        self.request_counts: Dict[str, Dict[str, Any]] = {}

    async def __call__(self, request: Request, call_next):
        start_time = time.time()

        # Get client IP
        client_ip = self.get_client_ip(request)

        # Check if IP is blocked
        if client_ip in self.blocked_ips:
            return JSONResponse(
                status_code=403,
                content={
                    "success": False,
                    "message": "IP address blocked due to suspicious activity",
                    "error_code": "IP_BLOCKED"
                }
            )

        # Security headers check
        security_check = self.perform_security_checks(request)
        if security_check:
            return security_check

        # Process request
        try:
            response = await call_next(request)

            # Add security headers to response
            self.add_security_headers(response)

            # Log request
            processing_time = time.time() - start_time
            self.log_request(request, response, processing_time, client_ip)

            return response

        except Exception as e:
            logger.error(f"Request processing error: {e}")
            return JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "message": "Internal server error",
                    "error_code": "INTERNAL_ERROR"
                }
            )

    def get_client_ip(self, request: Request) -> str:
        """Extract client IP address from request"""
        # Check for forwarded headers
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()

        forwarded = request.headers.get("X-Forwarded")
        if forwarded:
            return forwarded.split(",")[0].strip()

        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip.strip()

        # Fall back to direct connection IP
        return request.client.host if request.client else "unknown"

    def perform_security_checks(self, request: Request) -> Optional[JSONResponse]:
        """Perform various security checks on the request"""

        # Check request size
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > 50 * 1024 * 1024:  # 50MB limit
                    return JSONResponse(
                        status_code=413,
                        content={
                            "success": False,
                            "message": "Request payload too large",
                            "error_code": "PAYLOAD_TOO_LARGE"
                        }
                    )
            except ValueError:
                pass

        # Check for suspicious patterns in URL
        url_path = str(request.url.path).lower()
        suspicious_patterns = [
            "../", "..\\", "<script", "javascript:", "eval(", "alert(",
            "union select", "drop table", "insert into", "update set",
            "delete from", "create table", "alter table"
        ]

        for pattern in suspicious_patterns:
            if pattern in url_path:
                logger.warning(f"Suspicious URL pattern detected: {url_path} from {self.get_client_ip(request)}")
                return JSONResponse(
                    status_code=400,
                    content={
                        "success": False,
                        "message": "Invalid request format",
                        "error_code": "INVALID_REQUEST"
                    }
                )

        # Check User-Agent
        user_agent = request.headers.get("user-agent", "").lower()
        if not user_agent or len(user_agent) < 10:
            logger.warning(f"Suspicious user agent: {user_agent} from {self.get_client_ip(request)}")
            # Don't block, just log for now

        # Check for common attack headers
        attack_headers = [
            "x-forwarded-host", "x-cluster-client-ip", "x-real-ip",
            "cf-connecting-ip", "true-client-ip"
        ]

        for header in attack_headers:
            value = request.headers.get(header, "")
            if value and self.is_suspicious_ip(value):
                logger.warning(f"Suspicious header {header}: {value}")

        return None

    def is_suspicious_ip(self, ip: str) -> bool:
        """Check if IP address looks suspicious"""
        # Basic check for common attack patterns
        suspicious_patterns = [
            "127.0.0.1", "localhost", "0.0.0.0", "::1",
            "10.", "192.168.", "172."  # Private IPs in public headers
        ]

        return any(pattern in ip.lower() for pattern in suspicious_patterns)

    def add_security_headers(self, response: Response):
        """Add security headers to response"""
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        response.headers["X-Railway-QR-System"] = "v2.0"

    def log_request(self, request: Request, response: Response, processing_time: float, client_ip: str):
        """Log request for security monitoring"""
        log_data = {
            "ip": client_ip,
            "method": request.method,
            "path": str(request.url.path),
            "status_code": getattr(response, "status_code", 0),
            "processing_time": round(processing_time, 3),
            "user_agent": request.headers.get("user-agent", ""),
            "timestamp": time.time()
        }

        # Log as INFO for normal requests, WARNING for errors
        if log_data["status_code"] >= 400:
            logger.warning(f"HTTP {log_data['status_code']}: {log_data}")
        else:
            logger.info(f"Request: {log_data}")

    def block_ip(self, ip: str, reason: str = "Suspicious activity"):
        """Block an IP address"""
        self.blocked_ips.add(ip)
        logger.warning(f"IP blocked: {ip}, Reason: {reason}")

    def unblock_ip(self, ip: str):
        """Unblock an IP address"""
        self.blocked_ips.discard(ip)
        logger.info(f"IP unblocked: {ip}")
