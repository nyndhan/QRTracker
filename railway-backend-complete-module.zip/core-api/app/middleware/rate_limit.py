"""
Rate Limiting Middleware
"""

from fastapi import Request, Response, HTTPException
from fastapi.responses import JSONResponse
import time
import asyncio
import logging
from typing import Dict, Any, Optional
from collections import defaultdict, deque
import redis.asyncio as redis

logger = logging.getLogger(__name__)


class RateLimitMiddleware:
    """Advanced rate limiting middleware with Redis backend"""

    def __init__(self, redis_url: str = None):
        self.redis_client = None
        if redis_url:
            try:
                self.redis_client = redis.from_url(redis_url, decode_responses=True)
            except Exception as e:
                logger.warning(f"Redis connection failed, using memory-based rate limiting: {e}")

        # Fallback to memory-based rate limiting
        self.memory_store: Dict[str, Dict[str, Any]] = defaultdict(dict)
        self.cleanup_interval = 300  # 5 minutes
        self.last_cleanup = time.time()

        # Rate limit configurations
        self.rate_limits = {
            "general": {"requests": 1000, "window": 3600},  # 1000 requests per hour
            "auth": {"requests": 10, "window": 300},         # 10 auth requests per 5 minutes
            "qr_generation": {"requests": 100, "window": 600}, # 100 QR generations per 10 minutes
            "qr_scan": {"requests": 500, "window": 300},     # 500 QR scans per 5 minutes
            "api_key": {"requests": 5000, "window": 3600},   # 5000 requests per hour for API keys
            "admin": {"requests": 10000, "window": 3600}     # 10000 requests per hour for admins
        }

    async def __call__(self, request: Request, call_next):
        # Get client identifier
        client_id = await self.get_client_identifier(request)

        # Determine rate limit type
        rate_limit_type = self.get_rate_limit_type(request)

        # Check rate limit
        is_allowed, retry_after = await self.check_rate_limit(client_id, rate_limit_type)

        if not is_allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "success": False,
                    "message": "Rate limit exceeded",
                    "error_code": "RATE_LIMIT_EXCEEDED",
                    "retry_after": retry_after
                },
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit": str(self.rate_limits[rate_limit_type]["requests"]),
                    "X-RateLimit-Window": str(self.rate_limits[rate_limit_type]["window"]),
                    "X-RateLimit-Remaining": "0"
                }
            )

        # Process request
        response = await call_next(request)

        # Add rate limit headers
        remaining = await self.get_remaining_requests(client_id, rate_limit_type)
        response.headers["X-RateLimit-Limit"] = str(self.rate_limits[rate_limit_type]["requests"])
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Window"] = str(self.rate_limits[rate_limit_type]["window"])
        response.headers["X-RateLimit-Type"] = rate_limit_type

        return response

    async def get_client_identifier(self, request: Request) -> str:
        """Get unique client identifier for rate limiting"""
        # Check for API key first
        api_key = request.headers.get("X-API-Key") or request.query_params.get("api_key")
        if api_key:
            return f"api_key:{api_key[:16]}..."  # Use partial API key for security

        # Check for authenticated user
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            try:
                # Extract user ID from token (simplified)
                token = auth_header.split(" ")[1]
                # In real implementation, decode JWT to get user ID
                return f"user:token:{token[:16]}..."
            except:
                pass

        # Fall back to IP address
        client_ip = self.get_client_ip(request)
        return f"ip:{client_ip}"

    def get_client_ip(self, request: Request) -> str:
        """Extract client IP address"""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()

        return request.client.host if request.client else "unknown"

    def get_rate_limit_type(self, request: Request) -> str:
        """Determine the rate limit type based on request"""
        path = request.url.path.lower()

        # Authentication endpoints
        if "/auth/" in path:
            return "auth"

        # QR operations
        if "/qr/" in path:
            if "generate" in path:
                return "qr_generation"
            elif "scan" in path:
                return "qr_scan"

        # Check for API key (higher limits)
        if request.headers.get("X-API-Key"):
            return "api_key"

        # Check for admin user (simplified)
        auth_header = request.headers.get("Authorization")
        if auth_header and "admin" in str(request.url):  # Simplified admin check
            return "admin"

        return "general"

    async def check_rate_limit(self, client_id: str, rate_limit_type: str) -> tuple[bool, int]:
        """Check if client is within rate limits"""
        limit_config = self.rate_limits[rate_limit_type]
        max_requests = limit_config["requests"]
        window_seconds = limit_config["window"]

        if self.redis_client:
            return await self._check_rate_limit_redis(client_id, rate_limit_type, max_requests, window_seconds)
        else:
            return await self._check_rate_limit_memory(client_id, rate_limit_type, max_requests, window_seconds)

    async def _check_rate_limit_redis(self, client_id: str, rate_limit_type: str, 
                                    max_requests: int, window_seconds: int) -> tuple[bool, int]:
        """Redis-based rate limiting with sliding window"""
        key = f"rate_limit:{rate_limit_type}:{client_id}"
        current_time = int(time.time())

        try:
            # Use Redis pipeline for atomic operations
            pipe = self.redis_client.pipeline()

            # Remove expired entries
            pipe.zremrangebyscore(key, 0, current_time - window_seconds)

            # Count current requests
            pipe.zcard(key)

            # Add current request
            pipe.zadd(key, {str(current_time): current_time})

            # Set expiration
            pipe.expire(key, window_seconds)

            results = await pipe.execute()
            current_requests = results[1]

            if current_requests >= max_requests:
                # Calculate retry after
                oldest_request_time = await self.redis_client.zrange(key, 0, 0, withscores=True)
                if oldest_request_time:
                    retry_after = int(oldest_request_time[0][1]) + window_seconds - current_time
                    return False, max(retry_after, 1)
                return False, window_seconds

            return True, 0

        except Exception as e:
            logger.error(f"Redis rate limit error: {e}")
            # Fall back to memory-based rate limiting
            return await self._check_rate_limit_memory(client_id, rate_limit_type, max_requests, window_seconds)

    async def _check_rate_limit_memory(self, client_id: str, rate_limit_type: str, 
                                     max_requests: int, window_seconds: int) -> tuple[bool, int]:
        """Memory-based rate limiting with sliding window"""
        key = f"{rate_limit_type}:{client_id}"
        current_time = time.time()

        # Cleanup old entries periodically
        if current_time - self.last_cleanup > self.cleanup_interval:
            await self._cleanup_memory_store()
            self.last_cleanup = current_time

        if key not in self.memory_store:
            self.memory_store[key] = {"requests": deque(), "first_request": current_time}

        client_data = self.memory_store[key]
        requests = client_data["requests"]

        # Remove expired requests
        while requests and requests[0] < current_time - window_seconds:
            requests.popleft()

        # Check if limit exceeded
        if len(requests) >= max_requests:
            # Calculate retry after
            oldest_request = requests[0] if requests else current_time
            retry_after = int(oldest_request + window_seconds - current_time)
            return False, max(retry_after, 1)

        # Add current request
        requests.append(current_time)

        return True, 0

    async def get_remaining_requests(self, client_id: str, rate_limit_type: str) -> int:
        """Get remaining requests for client"""
        limit_config = self.rate_limits[rate_limit_type]
        max_requests = limit_config["requests"]
        window_seconds = limit_config["window"]

        if self.redis_client:
            try:
                key = f"rate_limit:{rate_limit_type}:{client_id}"
                current_time = int(time.time())

                # Count current requests
                await self.redis_client.zremrangebyscore(key, 0, current_time - window_seconds)
                current_requests = await self.redis_client.zcard(key)

                return max(0, max_requests - current_requests)

            except Exception as e:
                logger.error(f"Redis remaining requests error: {e}")

        # Memory fallback
        key = f"{rate_limit_type}:{client_id}"
        if key not in self.memory_store:
            return max_requests

        requests = self.memory_store[key]["requests"]
        current_time = time.time()

        # Remove expired requests
        while requests and requests[0] < current_time - window_seconds:
            requests.popleft()

        return max(0, max_requests - len(requests))

    async def _cleanup_memory_store(self):
        """Clean up expired entries from memory store"""
        current_time = time.time()
        keys_to_remove = []

        for key, data in self.memory_store.items():
            requests = data["requests"]

            # Remove all expired requests
            while requests and requests[0] < current_time - 3600:  # Keep for 1 hour max
                requests.popleft()

            # Remove empty entries
            if not requests:
                keys_to_remove.append(key)

        for key in keys_to_remove:
            del self.memory_store[key]

        logger.info(f"Cleaned up {len(keys_to_remove)} expired rate limit entries")

    async def reset_rate_limit(self, client_id: str, rate_limit_type: str):
        """Reset rate limit for a specific client (admin function)"""
        if self.redis_client:
            try:
                key = f"rate_limit:{rate_limit_type}:{client_id}"
                await self.redis_client.delete(key)
                logger.info(f"Rate limit reset for {client_id} ({rate_limit_type})")
            except Exception as e:
                logger.error(f"Redis rate limit reset error: {e}")

        # Memory fallback
        key = f"{rate_limit_type}:{client_id}"
        if key in self.memory_store:
            del self.memory_store[key]
            logger.info(f"Memory rate limit reset for {client_id} ({rate_limit_type})")

    def update_rate_limits(self, new_limits: Dict[str, Dict[str, int]]):
        """Update rate limit configurations"""
        for limit_type, config in new_limits.items():
            if limit_type in self.rate_limits:
                self.rate_limits[limit_type].update(config)
                logger.info(f"Updated rate limit for {limit_type}: {config}")

    async def get_rate_limit_status(self, client_id: str) -> Dict[str, Any]:
        """Get comprehensive rate limit status for a client"""
        status = {}

        for rate_limit_type in self.rate_limits.keys():
            remaining = await self.get_remaining_requests(client_id, rate_limit_type)
            limit_config = self.rate_limits[rate_limit_type]

            status[rate_limit_type] = {
                "limit": limit_config["requests"],
                "window": limit_config["window"],
                "remaining": remaining,
                "used": limit_config["requests"] - remaining,
                "reset_time": int(time.time()) + limit_config["window"]
            }

        return status
