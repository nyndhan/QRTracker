"""
Railway Management API Routes
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body, status
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from uuid import UUID
import logging

from app.database import get_db
from app.models.railway_models import Track, RailwayComponent, TrackInspection, ComponentInspection, Vendor
from app.services.railway_service import RailwayService
from app.api.dependencies import get_current_user, check_permission
from app.schemas.railway_schemas import (
    TrackCreate, TrackUpdate, TrackResponse, TrackList,
    ComponentCreate, ComponentUpdate, ComponentResponse, ComponentList,
    InspectionCreate, InspectionUpdate, InspectionResponse, InspectionList,
    VendorCreate, VendorUpdate, VendorResponse, VendorList
)
from app.utils.responses import success_response, error_response
from app.utils.pagination import paginate

router = APIRouter()
logger = logging.getLogger(__name__)


# Track Management Endpoints
@router.get("/tracks", response_model=TrackList)
async def get_tracks(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    zone: Optional[str] = Query(None),
    division: Optional[str] = Query(None),
    track_class: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.track.read"))
):
    """Get paginated list of tracks with filtering"""
    try:
        railway_service = RailwayService(db)

        filters = {}
        if zone:
            filters["zone"] = zone
        if division:
            filters["division"] = division
        if track_class:
            filters["track_class"] = track_class
        if status:
            filters["status"] = status
        if search:
            filters["search"] = search

        tracks, total = railway_service.get_tracks(
            page=page,
            page_size=page_size,
            filters=filters
        )

        return success_response(
            data={
                "tracks": tracks,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total": total,
                    "pages": (total + page_size - 1) // page_size
                }
            }
        )

    except Exception as e:
        logger.error(f"Error getting tracks: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve tracks")


@router.post("/tracks", response_model=TrackResponse, status_code=status.HTTP_201_CREATED)
async def create_track(
    track_data: TrackCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.track.create"))
):
    """Create a new track"""
    try:
        railway_service = RailwayService(db)
        track = railway_service.create_track(track_data, current_user.id)

        logger.info(f"Track created: {track.track_code} by user {current_user.username}")

        return success_response(
            data=track,
            message="Track created successfully",
            status_code=201
        )

    except ValueError as e:
        logger.warning(f"Track creation validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating track: {e}")
        raise HTTPException(status_code=500, detail="Failed to create track")


@router.get("/tracks/{track_id}", response_model=TrackResponse)
async def get_track(
    track_id: UUID = Path(..., description="Track ID"),
    include_components: bool = Query(False, description="Include track components"),
    include_inspections: bool = Query(False, description="Include recent inspections"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.track.read"))
):
    """Get track details by ID"""
    try:
        railway_service = RailwayService(db)
        track = railway_service.get_track_by_id(
            track_id,
            include_components=include_components,
            include_inspections=include_inspections
        )

        if not track:
            raise HTTPException(status_code=404, detail="Track not found")

        return success_response(data=track)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting track {track_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve track")


@router.put("/tracks/{track_id}", response_model=TrackResponse)
async def update_track(
    track_id: UUID = Path(..., description="Track ID"),
    track_data: TrackUpdate = Body(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.track.update"))
):
    """Update track information"""
    try:
        railway_service = RailwayService(db)
        track = railway_service.update_track(track_id, track_data, current_user.id)

        if not track:
            raise HTTPException(status_code=404, detail="Track not found")

        logger.info(f"Track updated: {track.track_code} by user {current_user.username}")

        return success_response(
            data=track,
            message="Track updated successfully"
        )

    except ValueError as e:
        logger.warning(f"Track update validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating track {track_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to update track")


@router.delete("/tracks/{track_id}")
async def delete_track(
    track_id: UUID = Path(..., description="Track ID"),
    force: bool = Query(False, description="Force delete with components"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.track.delete"))
):
    """Delete track (soft delete by default)"""
    try:
        railway_service = RailwayService(db)
        success = railway_service.delete_track(track_id, force=force, deleted_by=current_user.id)

        if not success:
            raise HTTPException(status_code=404, detail="Track not found")

        logger.info(f"Track deleted: {track_id} by user {current_user.username}")

        return success_response(message="Track deleted successfully")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting track {track_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete track")


# Component Management Endpoints
@router.get("/components", response_model=ComponentList)
async def get_components(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    component_type: Optional[str] = Query(None),
    track_id: Optional[UUID] = Query(None),
    manufacturer: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    serial_number: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.component.read"))
):
    """Get paginated list of railway components with filtering"""
    try:
        railway_service = RailwayService(db)

        filters = {}
        if component_type:
            filters["component_type"] = component_type
        if track_id:
            filters["track_id"] = track_id
        if manufacturer:
            filters["manufacturer"] = manufacturer
        if status:
            filters["status"] = status
        if serial_number:
            filters["serial_number"] = serial_number
        if search:
            filters["search"] = search

        components, total = railway_service.get_components(
            page=page,
            page_size=page_size,
            filters=filters
        )

        return success_response(
            data={
                "components": components,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total": total,
                    "pages": (total + page_size - 1) // page_size
                }
            }
        )

    except Exception as e:
        logger.error(f"Error getting components: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve components")


@router.post("/components", response_model=ComponentResponse, status_code=status.HTTP_201_CREATED)
async def create_component(
    component_data: ComponentCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.component.create"))
):
    """Create a new railway component"""
    try:
        railway_service = RailwayService(db)
        component = railway_service.create_component(component_data, current_user.id)

        logger.info(f"Component created: {component.serial_number} by user {current_user.username}")

        return success_response(
            data=component,
            message="Component created successfully",
            status_code=201
        )

    except ValueError as e:
        logger.warning(f"Component creation validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating component: {e}")
        raise HTTPException(status_code=500, detail="Failed to create component")


@router.get("/components/{component_id}", response_model=ComponentResponse)
async def get_component(
    component_id: UUID = Path(..., description="Component ID"),
    include_qr_code: bool = Query(True, description="Include QR code data"),
    include_history: bool = Query(False, description="Include maintenance history"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.component.read"))
):
    """Get component details by ID"""
    try:
        railway_service = RailwayService(db)
        component = railway_service.get_component_by_id(
            component_id,
            include_qr_code=include_qr_code,
            include_history=include_history
        )

        if not component:
            raise HTTPException(status_code=404, detail="Component not found")

        return success_response(data=component)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting component {component_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve component")


# Digital Inspection Endpoints
@router.post("/inspections/digital", response_model=InspectionResponse, status_code=status.HTTP_201_CREATED)
async def create_digital_inspection(
    inspection_data: InspectionCreate,
    qr_scan_data: Optional[Dict[str, Any]] = Body(None),
    location_data: Optional[Dict[str, Any]] = Body(None),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.inspection.create"))
):
    """Create a new digital inspection with QR scan integration"""
    try:
        railway_service = RailwayService(db)

        # Enhanced inspection with QR integration
        inspection = railway_service.create_digital_inspection(
            inspection_data,
            qr_scan_data=qr_scan_data,
            location_data=location_data,
            inspector_id=current_user.id
        )

        logger.info(f"Digital inspection created: {inspection.inspection_id} by {current_user.username}")

        return success_response(
            data=inspection,
            message="Digital inspection created successfully",
            status_code=201
        )

    except ValueError as e:
        logger.warning(f"Inspection creation validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating digital inspection: {e}")
        raise HTTPException(status_code=500, detail="Failed to create inspection")


# Bulk Operations
@router.post("/components/bulk-import")
async def bulk_import_components(
    components_data: List[ComponentCreate],
    validate_only: bool = Query(False, description="Only validate without importing"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.component.bulk_create"))
):
    """Bulk import railway components"""
    try:
        railway_service = RailwayService(db)

        result = railway_service.bulk_import_components(
            components_data,
            validate_only=validate_only,
            imported_by=current_user.id
        )

        message = "Components validated successfully" if validate_only else "Components imported successfully"
        logger.info(f"Bulk import: {len(components_data)} components by {current_user.username}")

        return success_response(
            data=result,
            message=message
        )

    except ValueError as e:
        logger.warning(f"Bulk import validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error in bulk import: {e}")
        raise HTTPException(status_code=500, detail="Failed to import components")


# Analytics and Reports
@router.get("/analytics/dashboard")
async def get_railway_analytics(
    timeframe: str = Query("7d", regex="^(1d|7d|30d|90d|1y)$"),
    zone: Optional[str] = Query(None),
    division: Optional[str] = Query(None),
    component_type: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    _: bool = Depends(check_permission("railway.analytics.read"))
):
    """Get railway management analytics for dashboard"""
    try:
        railway_service = RailwayService(db)

        analytics = railway_service.get_railway_analytics(
            timeframe=timeframe,
            zone=zone,
            division=division,
            component_type=component_type
        )

        return success_response(data=analytics)

    except Exception as e:
        logger.error(f"Error getting railway analytics: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve analytics")


# Health check for railway module
@router.get("/health")
async def railway_health_check(
    db: Session = Depends(get_db)
):
    """Health check for railway management module"""
    try:
        # Check database connectivity
        db.execute("SELECT 1")

        # Get basic statistics
        railway_service = RailwayService(db)
        stats = railway_service.get_basic_statistics()

        return {
            "status": "healthy",
            "module": "railway_management",
            "database": "connected",
            "statistics": stats,
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Railway module health check failed: {e}")
        raise HTTPException(status_code=503, detail="Railway module unhealthy")
