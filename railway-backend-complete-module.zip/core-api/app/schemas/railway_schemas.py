"""
Railway API Schemas for Request/Response validation
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID
import enum


class ComponentType(str, enum.Enum):
    ELASTIC_RAIL_CLIP = "elastic_rail_clip"
    RAIL_PAD = "rail_pad"
    LINER = "liner"
    SLEEPER = "sleeper"


class ComponentStatus(str, enum.Enum):
    ACTIVE = "active"
    MAINTENANCE = "maintenance"
    DAMAGED = "damaged"
    REPLACED = "replaced"
    RETIRED = "retired"


# Track Schemas
class TrackBase(BaseModel):
    track_code: str = Field(..., description="Unique track code")
    track_name: str = Field(..., description="Track name")
    zone: str = Field(..., description="Railway zone")
    division: str = Field(..., description="Railway division")
    section: str = Field(..., description="Railway section")
    gauge: Optional[str] = Field("1435", description="Track gauge in mm")
    track_class: str = Field(..., description="Track class (A, B, C, D, E)")
    max_speed: Optional[int] = Field(None, description="Maximum speed in km/h")
    start_location: Optional[str] = Field(None, description="Start location")
    end_location: Optional[str] = Field(None, description="End location")
    total_length: Optional[float] = Field(None, description="Total length in km")
    start_latitude: Optional[float] = Field(None, description="Start latitude")
    start_longitude: Optional[float] = Field(None, description="Start longitude")
    end_latitude: Optional[float] = Field(None, description="End latitude")
    end_longitude: Optional[float] = Field(None, description="End longitude")
    status: Optional[str] = Field("active", description="Track status")
    commissioned_date: Optional[datetime] = Field(None, description="Commission date")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    notes: Optional[str] = Field(None, description="Notes")

    @validator('track_code')
    def validate_track_code(cls, v):
        if not v or len(v.strip()) < 3:
            raise ValueError('Track code must be at least 3 characters')
        return v.upper().strip()

    @validator('zone', 'division')
    def validate_zone_division(cls, v):
        if not v or len(v.strip()) < 2:
            raise ValueError('Zone and division must be at least 2 characters')
        return v.upper().strip()

    @validator('track_class')
    def validate_track_class(cls, v):
        if v not in ['A', 'B', 'C', 'D', 'E']:
            raise ValueError('Track class must be A, B, C, D, or E')
        return v.upper()


class TrackCreate(TrackBase):
    pass


class TrackUpdate(BaseModel):
    track_name: Optional[str] = None
    zone: Optional[str] = None
    division: Optional[str] = None
    section: Optional[str] = None
    gauge: Optional[str] = None
    track_class: Optional[str] = None
    max_speed: Optional[int] = None
    start_location: Optional[str] = None
    end_location: Optional[str] = None
    total_length: Optional[float] = None
    start_latitude: Optional[float] = None
    start_longitude: Optional[float] = None
    end_latitude: Optional[float] = None
    end_longitude: Optional[float] = None
    status: Optional[str] = None
    commissioned_date: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None


class TrackResponse(TrackBase):
    id: UUID
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID]
    updated_by: Optional[UUID]
    component_count: Optional[int] = None
    last_inspection_date: Optional[datetime] = None
    next_inspection_date: Optional[datetime] = None

    class Config:
        from_attributes = True


class TrackList(BaseModel):
    tracks: List[TrackResponse]
    total: int
    page: int
    page_size: int
    pages: int


# Component Schemas
class ComponentBase(BaseModel):
    component_id: Optional[str] = Field(None, description="Component ID (auto-generated if not provided)")
    serial_number: str = Field(..., description="Component serial number")
    component_type: ComponentType = Field(..., description="Type of component")
    manufacturer: str = Field(..., description="Manufacturer name")
    model: Optional[str] = Field(None, description="Component model")
    batch_number: Optional[str] = Field(None, description="Manufacturing batch number")
    track_id: UUID = Field(..., description="Associated track ID")
    chainage: Optional[float] = Field(None, description="Position on track in km")
    side: Optional[str] = Field(None, description="Side placement (LEFT, RIGHT, CENTER)")
    installation_date: datetime = Field(..., description="Installation date")
    installation_crew: Optional[str] = Field(None, description="Installation crew")
    installation_method: Optional[str] = Field(None, description="Installation method")
    specifications: Optional[Dict[str, Any]] = Field(None, description="Technical specifications")
    dimensions: Optional[Dict[str, Any]] = Field(None, description="Dimensions")
    material: Optional[str] = Field(None, description="Material type")
    grade: Optional[str] = Field(None, description="Material grade")
    status: Optional[ComponentStatus] = Field(ComponentStatus.ACTIVE, description="Component status")
    warranty_start: Optional[datetime] = Field(None, description="Warranty start date")
    warranty_end: Optional[datetime] = Field(None, description="Warranty end date")
    warranty_provider: Optional[str] = Field(None, description="Warranty provider")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    notes: Optional[str] = Field(None, description="Notes")
    tags: Optional[List[str]] = Field(None, description="Tags")

    @validator('serial_number')
    def validate_serial_number(cls, v):
        if not v or len(v.strip()) < 6:
            raise ValueError('Serial number must be at least 6 characters')
        return v.upper().strip()

    @validator('manufacturer')
    def validate_manufacturer(cls, v):
        if not v or len(v.strip()) < 2:
            raise ValueError('Manufacturer name must be at least 2 characters')
        return v.strip()

    @validator('chainage')
    def validate_chainage(cls, v):
        if v is not None and (v < 0 or v > 10000):
            raise ValueError('Chainage must be between 0 and 10000 km')
        return v

    @validator('side')
    def validate_side(cls, v):
        if v and v.upper() not in ['LEFT', 'RIGHT', 'CENTER', 'L', 'R', 'C']:
            raise ValueError('Side must be LEFT, RIGHT, or CENTER')
        return v.upper() if v else v


class ComponentCreate(ComponentBase):
    pass


class ComponentUpdate(BaseModel):
    component_id: Optional[str] = None
    model: Optional[str] = None
    batch_number: Optional[str] = None
    chainage: Optional[float] = None
    side: Optional[str] = None
    installation_crew: Optional[str] = None
    installation_method: Optional[str] = None
    specifications: Optional[Dict[str, Any]] = None
    dimensions: Optional[Dict[str, Any]] = None
    material: Optional[str] = None
    grade: Optional[str] = None
    status: Optional[ComponentStatus] = None
    condition_score: Optional[float] = None
    warranty_start: Optional[datetime] = None
    warranty_end: Optional[datetime] = None
    warranty_provider: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = None


class ComponentResponse(ComponentBase):
    id: UUID
    condition_score: Optional[float] = None
    last_inspection_date: Optional[datetime] = None
    next_inspection_date: Optional[datetime] = None
    qr_code_id: Optional[UUID] = None
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID] = None
    updated_by: Optional[UUID] = None
    track: Optional[TrackResponse] = None
    qr_code: Optional[Dict[str, Any]] = None
    maintenance_history: Optional[List[Dict[str, Any]]] = None

    class Config:
        from_attributes = True


class ComponentList(BaseModel):
    components: List[ComponentResponse]
    total: int
    page: int
    page_size: int
    pages: int


# Inspection Schemas
class InspectionBase(BaseModel):
    component_id: UUID = Field(..., description="Component being inspected")
    inspector_name: str = Field(..., description="Inspector name")
    inspection_method: Optional[str] = Field("visual", description="Inspection method")
    condition_rating: str = Field(..., description="Condition rating")
    condition_score: float = Field(..., ge=0, le=100, description="Condition score (0-100)")
    wear_level: Optional[float] = Field(None, ge=0, le=100, description="Wear level percentage")
    damage_assessment: Optional[Dict[str, Any]] = Field(None, description="Damage assessment")
    measurements: Optional[Dict[str, Any]] = Field(None, description="Measurements taken")
    tolerances_met: Optional[bool] = Field(None, description="Whether tolerances are met")
    out_of_spec_items: Optional[List[str]] = Field(None, description="Out of specification items")
    action_required: str = Field(..., description="Action required")
    urgency_level: str = Field(..., description="Urgency level")
    recommended_action_date: Optional[datetime] = Field(None, description="Recommended action date")
    estimated_remaining_life: Optional[int] = Field(None, description="Estimated remaining life in days")
    photos: Optional[List[str]] = Field(None, description="Photo URLs")
    follow_up_required: Optional[bool] = Field(False, description="Follow-up required")
    follow_up_date: Optional[datetime] = Field(None, description="Follow-up date")

    @validator('condition_rating')
    def validate_condition_rating(cls, v):
        valid_ratings = ['excellent', 'good', 'fair', 'poor', 'critical']
        if v.lower() not in valid_ratings:
            raise ValueError(f'Condition rating must be one of: {", ".join(valid_ratings)}')
        return v.lower()

    @validator('action_required')
    def validate_action_required(cls, v):
        valid_actions = ['none', 'monitor', 'repair', 'replace', 'investigate']
        if v.lower() not in valid_actions:
            raise ValueError(f'Action required must be one of: {", ".join(valid_actions)}')
        return v.lower()

    @validator('urgency_level')
    def validate_urgency_level(cls, v):
        valid_urgencies = ['low', 'medium', 'high', 'critical']
        if v.lower() not in valid_urgencies:
            raise ValueError(f'Urgency level must be one of: {", ".join(valid_urgencies)}')
        return v.lower()


class InspectionCreate(InspectionBase):
    pass


class InspectionUpdate(BaseModel):
    inspector_name: Optional[str] = None
    inspection_method: Optional[str] = None
    condition_rating: Optional[str] = None
    condition_score: Optional[float] = Field(None, ge=0, le=100)
    wear_level: Optional[float] = Field(None, ge=0, le=100)
    damage_assessment: Optional[Dict[str, Any]] = None
    measurements: Optional[Dict[str, Any]] = None
    tolerances_met: Optional[bool] = None
    out_of_spec_items: Optional[List[str]] = None
    action_required: Optional[str] = None
    urgency_level: Optional[str] = None
    recommended_action_date: Optional[datetime] = None
    estimated_remaining_life: Optional[int] = None
    photos: Optional[List[str]] = None
    follow_up_required: Optional[bool] = None
    follow_up_date: Optional[datetime] = None
    corrective_actions_taken: Optional[str] = None


class InspectionResponse(InspectionBase):
    id: UUID
    inspection_id: str
    inspection_date: datetime
    qr_scanned: Optional[bool] = None
    qr_scan_time: Optional[datetime] = None
    qr_scan_location: Optional[Dict[str, Any]] = None
    inspection_report_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    component: Optional[ComponentResponse] = None

    class Config:
        from_attributes = True


class InspectionList(BaseModel):
    inspections: List[InspectionResponse]
    total: int
    page: int
    page_size: int
    pages: int


# Vendor Schemas
class VendorBase(BaseModel):
    vendor_code: str = Field(..., description="Unique vendor code")
    vendor_name: str = Field(..., description="Vendor name")
    contact_person: Optional[str] = Field(None, description="Contact person")
    email: Optional[str] = Field(None, description="Email address")
    phone: Optional[str] = Field(None, description="Phone number")
    website: Optional[str] = Field(None, description="Website URL")
    address_line1: Optional[str] = Field(None, description="Address line 1")
    address_line2: Optional[str] = Field(None, description="Address line 2")
    city: Optional[str] = Field(None, description="City")
    state: Optional[str] = Field(None, description="State")
    postal_code: Optional[str] = Field(None, description="Postal code")
    country: Optional[str] = Field("India", description="Country")
    registration_number: Optional[str] = Field(None, description="Registration number")
    tax_id: Optional[str] = Field(None, description="Tax ID")
    certification_details: Optional[Dict[str, Any]] = Field(None, description="Certifications")
    specializations: Optional[List[str]] = Field(None, description="Specializations")
    railway_approved: Optional[bool] = Field(False, description="Railway approved")
    quality_rating: Optional[float] = Field(None, ge=0, le=5, description="Quality rating (0-5)")
    status: Optional[str] = Field("active", description="Vendor status")

    @validator('vendor_code')
    def validate_vendor_code(cls, v):
        if not v or len(v.strip()) < 3:
            raise ValueError('Vendor code must be at least 3 characters')
        return v.upper().strip()

    @validator('email')
    def validate_email(cls, v):
        if v and '@' not in v:
            raise ValueError('Invalid email format')
        return v

    @validator('quality_rating')
    def validate_quality_rating(cls, v):
        if v is not None and (v < 0 or v > 5):
            raise ValueError('Quality rating must be between 0 and 5')
        return v


class VendorCreate(VendorBase):
    pass


class VendorUpdate(BaseModel):
    vendor_name: Optional[str] = None
    contact_person: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    registration_number: Optional[str] = None
    tax_id: Optional[str] = None
    certification_details: Optional[Dict[str, Any]] = None
    specializations: Optional[List[str]] = None
    railway_approved: Optional[bool] = None
    quality_rating: Optional[float] = Field(None, ge=0, le=5)
    status: Optional[str] = None
    notes: Optional[str] = None


class VendorResponse(VendorBase):
    id: UUID
    approval_date: Optional[datetime] = None
    approval_validity: Optional[datetime] = None
    blacklisted: Optional[bool] = None
    blacklist_reason: Optional[str] = None
    delivery_performance: Optional[float] = None
    quality_performance: Optional[float] = None
    total_orders: Optional[int] = None
    total_value: Optional[float] = None
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID] = None

    class Config:
        from_attributes = True


class VendorList(BaseModel):
    vendors: List[VendorResponse]
    total: int
    page: int
    page_size: int
    pages: int


# Bulk operation schemas
class BulkImportRequest(BaseModel):
    components: List[ComponentCreate]
    validate_only: Optional[bool] = Field(False, description="Only validate without importing")


class BulkImportResponse(BaseModel):
    total: int
    successful: int
    failed: int
    errors: List[str]
    warnings: List[str]
    components: Optional[List[UUID]] = None


# Analytics schemas
class AnalyticsRequest(BaseModel):
    timeframe: Optional[str] = Field("7d", description="Time frame for analytics")
    zone: Optional[str] = Field(None, description="Filter by zone")
    division: Optional[str] = Field(None, description="Filter by division")
    component_type: Optional[str] = Field(None, description="Filter by component type")


class AnalyticsResponse(BaseModel):
    summary: Dict[str, Any]
    component_distribution: Dict[str, Any]
    condition_analysis: Dict[str, Any]
    inspection_trends: Dict[str, Any]
    maintenance_alerts: Dict[str, Any]
    performance_metrics: Dict[str, Any]
    timeframe: str
    filters: Dict[str, Any]
    generated_at: str
