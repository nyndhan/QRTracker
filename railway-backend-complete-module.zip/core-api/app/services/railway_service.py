"""
Railway Service - Business Logic for Railway Management
"""

from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, desc, asc, func
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
import logging
from datetime import datetime, timedelta

from app.models.railway_models import Track, RailwayComponent, TrackInspection, ComponentInspection, Vendor
from app.models.qr_models import QRCode
from app.models.user_models import User
from app.schemas.railway_schemas import TrackCreate, TrackUpdate, ComponentCreate, ComponentUpdate, InspectionCreate
from app.utils.railway_utils import generate_component_id, validate_track_code, calculate_component_health

logger = logging.getLogger(__name__)


class RailwayService:
    def __init__(self, db: Session):
        self.db = db

    # Track Management
    def get_tracks(self, page: int = 1, page_size: int = 20, filters: Dict[str, Any] = None) -> Tuple[List[Track], int]:
        """Get paginated tracks with filtering"""
        query = self.db.query(Track)

        # Apply filters
        if filters:
            if filters.get("zone"):
                query = query.filter(Track.zone == filters["zone"])
            if filters.get("division"):
                query = query.filter(Track.division == filters["division"])
            if filters.get("track_class"):
                query = query.filter(Track.track_class == filters["track_class"])
            if filters.get("status"):
                query = query.filter(Track.status == filters["status"])
            if filters.get("search"):
                search_term = f"%{filters['search']}%"
                query = query.filter(
                    or_(
                        Track.track_code.ilike(search_term),
                        Track.track_name.ilike(search_term),
                        Track.section.ilike(search_term)
                    )
                )

        # Get total count
        total = query.count()

        # Apply pagination and ordering
        tracks = query.order_by(Track.track_code).offset((page - 1) * page_size).limit(page_size).all()

        return tracks, total

    def create_track(self, track_data: TrackCreate, created_by: UUID) -> Track:
        """Create a new track"""
        # Validate track code
        if not validate_track_code(track_data.track_code):
            raise ValueError("Invalid track code format")

        # Check if track code already exists
        existing_track = self.db.query(Track).filter(Track.track_code == track_data.track_code).first()
        if existing_track:
            raise ValueError(f"Track with code {track_data.track_code} already exists")

        # Create track
        track = Track(
            **track_data.dict(),
            created_by=created_by,
            updated_by=created_by
        )

        self.db.add(track)
        self.db.commit()
        self.db.refresh(track)

        logger.info(f"Track created: {track.track_code}")
        return track

    def get_track_by_id(self, track_id: UUID, include_components: bool = False, include_inspections: bool = False) -> Optional[Track]:
        """Get track by ID with optional related data"""
        query = self.db.query(Track)

        if include_components:
            query = query.options(joinedload(Track.components))
        if include_inspections:
            query = query.options(joinedload(Track.inspections))

        return query.filter(Track.id == track_id).first()

    def update_track(self, track_id: UUID, track_data: TrackUpdate, updated_by: UUID) -> Optional[Track]:
        """Update track information"""
        track = self.db.query(Track).filter(Track.id == track_id).first()
        if not track:
            return None

        # Update fields
        update_data = track_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(track, field, value)

        track.updated_by = updated_by
        track.updated_at = datetime.utcnow()

        self.db.commit()
        self.db.refresh(track)

        logger.info(f"Track updated: {track.track_code}")
        return track

    def delete_track(self, track_id: UUID, force: bool = False, deleted_by: UUID = None) -> bool:
        """Delete track (soft delete by default)"""
        track = self.db.query(Track).filter(Track.id == track_id).first()
        if not track:
            return False

        # Check if track has components
        component_count = self.db.query(RailwayComponent).filter(RailwayComponent.track_id == track_id).count()
        if component_count > 0 and not force:
            raise ValueError(f"Track has {component_count} components. Use force=true to delete.")

        if force:
            # Hard delete
            self.db.delete(track)
        else:
            # Soft delete
            track.status = "deleted"
            track.updated_by = deleted_by
            track.updated_at = datetime.utcnow()

        self.db.commit()
        logger.info(f"Track deleted: {track.track_code}")
        return True

    # Component Management
    def get_components(self, page: int = 1, page_size: int = 20, filters: Dict[str, Any] = None) -> Tuple[List[RailwayComponent], int]:
        """Get paginated components with filtering"""
        query = self.db.query(RailwayComponent).options(
            joinedload(RailwayComponent.track),
            joinedload(RailwayComponent.qr_code)
        )

        # Apply filters
        if filters:
            if filters.get("component_type"):
                query = query.filter(RailwayComponent.component_type == filters["component_type"])
            if filters.get("track_id"):
                query = query.filter(RailwayComponent.track_id == filters["track_id"])
            if filters.get("manufacturer"):
                query = query.filter(RailwayComponent.manufacturer.ilike(f"%{filters['manufacturer']}%"))
            if filters.get("status"):
                query = query.filter(RailwayComponent.status == filters["status"])
            if filters.get("serial_number"):
                query = query.filter(RailwayComponent.serial_number.ilike(f"%{filters['serial_number']}%"))
            if filters.get("search"):
                search_term = f"%{filters['search']}%"
                query = query.filter(
                    or_(
                        RailwayComponent.serial_number.ilike(search_term),
                        RailwayComponent.component_id.ilike(search_term),
                        RailwayComponent.manufacturer.ilike(search_term)
                    )
                )

        # Get total count
        total = query.count()

        # Apply pagination and ordering
        components = query.order_by(RailwayComponent.installation_date.desc()).offset((page - 1) * page_size).limit(page_size).all()

        return components, total

    def create_component(self, component_data: ComponentCreate, created_by: UUID) -> RailwayComponent:
        """Create a new railway component"""
        # Generate component ID if not provided
        if not component_data.component_id:
            component_data.component_id = generate_component_id(
                component_data.component_type,
                component_data.manufacturer
            )

        # Check if serial number already exists
        existing_component = self.db.query(RailwayComponent).filter(
            RailwayComponent.serial_number == component_data.serial_number
        ).first()
        if existing_component:
            raise ValueError(f"Component with serial number {component_data.serial_number} already exists")

        # Verify track exists
        track = self.db.query(Track).filter(Track.id == component_data.track_id).first()
        if not track:
            raise ValueError("Invalid track ID")

        # Create component
        component = RailwayComponent(
            **component_data.dict(),
            created_by=created_by,
            updated_by=created_by
        )

        self.db.add(component)
        self.db.commit()
        self.db.refresh(component)

        logger.info(f"Component created: {component.serial_number}")
        return component

    def get_component_by_id(self, component_id: UUID, include_qr_code: bool = True, include_history: bool = False) -> Optional[RailwayComponent]:
        """Get component by ID with optional related data"""
        query = self.db.query(RailwayComponent).options(joinedload(RailwayComponent.track))

        if include_qr_code:
            query = query.options(joinedload(RailwayComponent.qr_code))
        if include_history:
            query = query.options(joinedload(RailwayComponent.maintenance_records))
            query = query.options(joinedload(RailwayComponent.inspections))

        return query.filter(RailwayComponent.id == component_id).first()

    def update_component_condition(self, component_id: UUID, condition_data: Dict[str, Any], updated_by: UUID) -> Optional[RailwayComponent]:
        """Update component condition and health metrics"""
        component = self.db.query(RailwayComponent).filter(RailwayComponent.id == component_id).first()
        if not component:
            return None

        # Calculate health score based on condition data
        health_score = calculate_component_health(condition_data, component.component_type)

        # Update component
        component.condition_score = health_score
        component.last_inspection_date = datetime.utcnow()

        # Set next inspection date based on condition
        if health_score >= 90:
            next_inspection_days = 90  # 3 months
        elif health_score >= 70:
            next_inspection_days = 60  # 2 months
        elif health_score >= 50:
            next_inspection_days = 30  # 1 month
        else:
            next_inspection_days = 14  # 2 weeks

        component.next_inspection_date = datetime.utcnow() + timedelta(days=next_inspection_days)
        component.updated_by = updated_by
        component.updated_at = datetime.utcnow()

        # Update status based on condition
        if health_score < 30:
            component.status = "damaged"
        elif health_score < 60:
            component.status = "maintenance"
        else:
            component.status = "active"

        self.db.commit()
        self.db.refresh(component)

        logger.info(f"Component condition updated: {component.serial_number}, health: {health_score}")
        return component

    # Digital Inspection
    def create_digital_inspection(self, inspection_data: InspectionCreate, qr_scan_data: Optional[Dict] = None, 
                                location_data: Optional[Dict] = None, inspector_id: UUID = None) -> ComponentInspection:
        """Create digital inspection with QR integration"""
        # Verify component exists
        component = self.db.query(RailwayComponent).filter(RailwayComponent.id == inspection_data.component_id).first()
        if not component:
            raise ValueError("Invalid component ID")

        # Generate inspection ID
        inspection_id = f"INS_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{component.component_id[-6:]}"

        # Create inspection
        inspection = ComponentInspection(
            inspection_id=inspection_id,
            component_id=inspection_data.component_id,
            inspection_date=datetime.utcnow(),
            inspector_name=inspection_data.inspector_name,
            inspection_method=inspection_data.inspection_method,
            condition_rating=inspection_data.condition_rating,
            condition_score=inspection_data.condition_score,
            wear_level=inspection_data.wear_level,
            damage_assessment=inspection_data.damage_assessment,
            measurements=inspection_data.measurements,
            tolerances_met=inspection_data.tolerances_met,
            out_of_spec_items=inspection_data.out_of_spec_items,
            action_required=inspection_data.action_required,
            urgency_level=inspection_data.urgency_level,
            recommended_action_date=inspection_data.recommended_action_date,
            estimated_remaining_life=inspection_data.estimated_remaining_life,
            photos=inspection_data.photos or [],
            follow_up_required=inspection_data.follow_up_required,
            follow_up_date=inspection_data.follow_up_date
        )

        # Add QR scan information if provided
        if qr_scan_data:
            inspection.qr_scanned = True
            inspection.qr_scan_time = datetime.utcnow()
            inspection.qr_scan_location = qr_scan_data.get("location")

        self.db.add(inspection)

        # Update component condition
        self.update_component_condition(
            inspection_data.component_id,
            {
                "condition_score": inspection_data.condition_score,
                "wear_level": inspection_data.wear_level,
                "damage_assessment": inspection_data.damage_assessment
            },
            inspector_id
        )

        self.db.commit()
        self.db.refresh(inspection)

        logger.info(f"Digital inspection created: {inspection.inspection_id}")
        return inspection

    # Bulk Operations
    def bulk_import_components(self, components_data: List[ComponentCreate], validate_only: bool = False, 
                             imported_by: UUID = None) -> Dict[str, Any]:
        """Bulk import railway components"""
        results = {
            "total": len(components_data),
            "successful": 0,
            "failed": 0,
            "errors": [],
            "warnings": []
        }

        created_components = []

        try:
            for i, component_data in enumerate(components_data):
                try:
                    # Validate component data
                    if not component_data.serial_number:
                        results["errors"].append(f"Row {i+1}: Serial number is required")
                        results["failed"] += 1
                        continue

                    # Check for duplicates
                    existing = self.db.query(RailwayComponent).filter(
                        RailwayComponent.serial_number == component_data.serial_number
                    ).first()
                    if existing:
                        results["warnings"].append(f"Row {i+1}: Component {component_data.serial_number} already exists")
                        results["failed"] += 1
                        continue

                    # Verify track exists
                    track = self.db.query(Track).filter(Track.id == component_data.track_id).first()
                    if not track:
                        results["errors"].append(f"Row {i+1}: Invalid track ID {component_data.track_id}")
                        results["failed"] += 1
                        continue

                    if not validate_only:
                        # Generate component ID
                        if not component_data.component_id:
                            component_data.component_id = generate_component_id(
                                component_data.component_type,
                                component_data.manufacturer
                            )

                        # Create component
                        component = RailwayComponent(
                            **component_data.dict(),
                            created_by=imported_by,
                            updated_by=imported_by
                        )

                        self.db.add(component)
                        created_components.append(component)

                    results["successful"] += 1

                except Exception as e:
                    results["errors"].append(f"Row {i+1}: {str(e)}")
                    results["failed"] += 1

            if not validate_only and created_components:
                self.db.commit()

                # Refresh all components
                for component in created_components:
                    self.db.refresh(component)

            results["components"] = [comp.id for comp in created_components] if not validate_only else None

        except Exception as e:
            self.db.rollback()
            logger.error(f"Bulk import failed: {e}")
            raise

        logger.info(f"Bulk import completed: {results['successful']} successful, {results['failed']} failed")
        return results

    # Analytics and Reports
    def get_railway_analytics(self, timeframe: str = "7d", zone: Optional[str] = None, 
                            division: Optional[str] = None, component_type: Optional[str] = None) -> Dict[str, Any]:
        """Get comprehensive railway analytics"""
        # Date range calculation
        now = datetime.utcnow()
        if timeframe == "1d":
            start_date = now - timedelta(days=1)
        elif timeframe == "7d":
            start_date = now - timedelta(days=7)
        elif timeframe == "30d":
            start_date = now - timedelta(days=30)
        elif timeframe == "90d":
            start_date = now - timedelta(days=90)
        elif timeframe == "1y":
            start_date = now - timedelta(days=365)
        else:
            start_date = now - timedelta(days=7)

        # Base queries
        track_query = self.db.query(Track)
        component_query = self.db.query(RailwayComponent)
        inspection_query = self.db.query(ComponentInspection).filter(
            ComponentInspection.inspection_date >= start_date
        )

        # Apply filters
        if zone:
            track_query = track_query.filter(Track.zone == zone)
            component_query = component_query.join(Track).filter(Track.zone == zone)

        if division:
            track_query = track_query.filter(Track.division == division)
            component_query = component_query.join(Track).filter(Track.division == division)

        if component_type:
            component_query = component_query.filter(RailwayComponent.component_type == component_type)

        # Calculate analytics
        analytics = {
            "summary": {
                "total_tracks": track_query.count(),
                "total_components": component_query.count(),
                "active_components": component_query.filter(RailwayComponent.status == "active").count(),
                "components_needing_maintenance": component_query.filter(
                    RailwayComponent.status.in_(["maintenance", "damaged"])
                ).count(),
                "inspections_completed": inspection_query.count(),
                "overdue_inspections": component_query.filter(
                    RailwayComponent.next_inspection_date < now
                ).count()
            },
            "component_distribution": self._get_component_distribution(component_query),
            "condition_analysis": self._get_condition_analysis(component_query),
            "inspection_trends": self._get_inspection_trends(inspection_query, start_date),
            "maintenance_alerts": self._get_maintenance_alerts(component_query),
            "performance_metrics": self._get_performance_metrics(component_query, inspection_query),
            "timeframe": timeframe,
            "filters": {
                "zone": zone,
                "division": division,
                "component_type": component_type
            },
            "generated_at": now.isoformat()
        }

        return analytics

    def _get_component_distribution(self, component_query) -> Dict[str, Any]:
        """Get component distribution by type"""
        distribution = self.db.query(
            RailwayComponent.component_type,
            func.count(RailwayComponent.id).label('count')
        ).group_by(RailwayComponent.component_type).all()

        return {
            "by_type": {item.component_type.value: item.count for item in distribution},
            "total": sum(item.count for item in distribution)
        }

    def _get_condition_analysis(self, component_query) -> Dict[str, Any]:
        """Analyze component conditions"""
        conditions = component_query.with_entities(
            RailwayComponent.condition_score,
            RailwayComponent.status
        ).all()

        excellent = sum(1 for c in conditions if c.condition_score and c.condition_score >= 90)
        good = sum(1 for c in conditions if c.condition_score and 70 <= c.condition_score < 90)
        fair = sum(1 for c in conditions if c.condition_score and 50 <= c.condition_score < 70)
        poor = sum(1 for c in conditions if c.condition_score and c.condition_score < 50)
        unknown = sum(1 for c in conditions if not c.condition_score)

        return {
            "condition_distribution": {
                "excellent": excellent,
                "good": good,
                "fair": fair,
                "poor": poor,
                "unknown": unknown
            },
            "average_condition_score": sum(c.condition_score for c in conditions if c.condition_score) / len([c for c in conditions if c.condition_score]) if conditions else 0,
            "components_at_risk": poor,
            "components_needing_attention": fair + poor
        }

    def _get_inspection_trends(self, inspection_query, start_date: datetime) -> Dict[str, Any]:
        """Get inspection trends over time"""
        daily_inspections = self.db.query(
            func.date(ComponentInspection.inspection_date).label('date'),
            func.count(ComponentInspection.id).label('count')
        ).filter(
            ComponentInspection.inspection_date >= start_date
        ).group_by(
            func.date(ComponentInspection.inspection_date)
        ).order_by('date').all()

        return {
            "daily_inspections": [
                {
                    "date": item.date.isoformat(),
                    "count": item.count
                } for item in daily_inspections
            ],
            "total_inspections": sum(item.count for item in daily_inspections),
            "average_per_day": sum(item.count for item in daily_inspections) / len(daily_inspections) if daily_inspections else 0
        }

    def _get_maintenance_alerts(self, component_query) -> Dict[str, Any]:
        """Get maintenance alerts and priorities"""
        now = datetime.utcnow()

        # Components needing immediate attention
        critical = component_query.filter(
            or_(
                RailwayComponent.condition_score < 30,
                RailwayComponent.status == "damaged"
            )
        ).count()

        # Components overdue for inspection
        overdue = component_query.filter(
            RailwayComponent.next_inspection_date < now
        ).count()

        # Components due for inspection soon
        due_soon = component_query.filter(
            and_(
                RailwayComponent.next_inspection_date >= now,
                RailwayComponent.next_inspection_date <= now + timedelta(days=7)
            )
        ).count()

        return {
            "critical_components": critical,
            "overdue_inspections": overdue,
            "due_soon_inspections": due_soon,
            "total_alerts": critical + overdue + due_soon
        }

    def _get_performance_metrics(self, component_query, inspection_query) -> Dict[str, Any]:
        """Get performance metrics"""
        # Component reliability
        total_components = component_query.count()
        active_components = component_query.filter(RailwayComponent.status == "active").count()

        reliability_rate = (active_components / total_components * 100) if total_components > 0 else 0

        # Inspection compliance
        inspected_recently = component_query.filter(
            RailwayComponent.last_inspection_date >= datetime.utcnow() - timedelta(days=90)
        ).count()

        inspection_compliance = (inspected_recently / total_components * 100) if total_components > 0 else 0

        return {
            "reliability_rate": round(reliability_rate, 2),
            "inspection_compliance": round(inspection_compliance, 2),
            "average_component_age": self._calculate_average_component_age(component_query),
            "maintenance_efficiency": self._calculate_maintenance_efficiency(component_query)
        }

    def _calculate_average_component_age(self, component_query) -> float:
        """Calculate average component age in days"""
        components = component_query.with_entities(RailwayComponent.installation_date).all()
        if not components:
            return 0

        now = datetime.utcnow()
        total_age = sum((now - c.installation_date).days for c in components if c.installation_date)
        return round(total_age / len(components), 1) if components else 0

    def _calculate_maintenance_efficiency(self, component_query) -> float:
        """Calculate maintenance efficiency percentage"""
        # This would be based on maintenance completion rates, downtime, etc.
        # For now, return a calculated value based on component conditions
        conditions = component_query.with_entities(RailwayComponent.condition_score).all()
        if not conditions:
            return 0

        valid_scores = [c.condition_score for c in conditions if c.condition_score]
        if not valid_scores:
            return 0

        average_condition = sum(valid_scores) / len(valid_scores)
        return round(average_condition, 2)

    def get_basic_statistics(self) -> Dict[str, Any]:
        """Get basic railway statistics for health check"""
        return {
            "tracks": self.db.query(Track).count(),
            "components": self.db.query(RailwayComponent).count(),
            "active_components": self.db.query(RailwayComponent).filter(RailwayComponent.status == "active").count(),
            "inspections_last_30_days": self.db.query(ComponentInspection).filter(
                ComponentInspection.inspection_date >= datetime.utcnow() - timedelta(days=30)
            ).count()
        }
