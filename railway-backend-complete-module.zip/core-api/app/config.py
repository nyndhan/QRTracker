"""
Configuration Management for Railway AI QR System
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, validator
import secrets


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Railway AI QR Management System"
    APP_VERSION: str = "2.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 4

    # Security
    SECRET_KEY: str = secrets.token_urlsafe(32)
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Database - PostgreSQL
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "railway_user"
    POSTGRES_PASSWORD: str = "railway_pass"
    POSTGRES_DB: str = "railway_qr_system"

    @property
    def DATABASE_URL(self) -> str:
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

    # MongoDB (for analytics)
    MONGODB_URL: str = "mongodb://localhost:27017"
    MONGODB_DB: str = "railway_analytics"

    # Redis (for caching)
    REDIS_URL: str = "redis://localhost:6379"
    REDIS_DB: int = 0

    # Microservices URLs
    QR_SERVICE_URL: str = "http://localhost:3001"
    REALTIME_SERVICE_URL: str = "http://localhost:3002"
    AI_SERVICE_URL: str = "http://localhost:8001"

    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001", 
        "http://localhost:8080",
        "http://127.0.0.1:3000"
    ]

    ALLOWED_HOSTS: List[str] = ["*"]

    # File Upload
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    UPLOAD_PATH: str = "uploads/"
    ALLOWED_EXTENSIONS: List[str] = [".jpg", ".jpeg", ".png", ".pdf", ".csv", ".xlsx"]

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/railway_core.log"

    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 1000
    RATE_LIMIT_WINDOW: int = 3600  # 1 hour

    # Metrics
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090

    # External APIs
    UDM_API_URL: Optional[str] = None
    UDM_API_KEY: Optional[str] = None
    TMS_API_URL: Optional[str] = None
    TMS_API_KEY: Optional[str] = None

    # SMS/Email
    SMS_PROVIDER: str = "twilio"
    SMS_API_KEY: Optional[str] = None
    EMAIL_PROVIDER: str = "smtp"
    SMTP_SERVER: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USERNAME: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None

    # AI/ML
    AI_MODEL_PATH: str = "models/"
    ENABLE_AI_PREDICTIONS: bool = True
    AI_BATCH_SIZE: int = 32

    # QR Configuration
    QR_DEFAULT_SIZE: int = 300
    QR_MAX_SIZE: int = 2000
    QR_MIN_SIZE: int = 100
    QR_DEFAULT_ERROR_CORRECTION: str = "M"

    # Railway Specific
    DEFAULT_ZONE: str = "CENTRAL"
    DEFAULT_DIVISION: str = "CR"
    COMPONENT_TYPES: List[str] = [
        "elastic_rail_clip",
        "rail_pad", 
        "liner",
        "sleeper"
    ]

    @validator("ALLOWED_ORIGINS", pre=True)
    def assemble_cors_origins(cls, v: str) -> List[str]:
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",")]
        elif isinstance(v, (list, str)):
            return v
        raise ValueError(v)

    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()

# Environment specific overrides
if settings.ENVIRONMENT == "production":
    settings.DEBUG = False
    settings.LOG_LEVEL = "WARNING"
elif settings.ENVIRONMENT == "development":
    settings.DEBUG = True
    settings.LOG_LEVEL = "DEBUG"
elif settings.ENVIRONMENT == "testing":
    settings.DEBUG = True
    settings.LOG_LEVEL = "DEBUG"
    settings.POSTGRES_DB = "test_railway_qr_system"
    settings.MONGODB_DB = "test_railway_analytics"
