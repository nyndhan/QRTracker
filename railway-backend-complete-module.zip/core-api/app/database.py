"""
Database Configuration and Connection Management
"""

from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
import asyncpg
import asyncio
import logging
from contextlib import asynccontextmanager

from app.config import settings

# SQLAlchemy setup
engine = create_engine(
    settings.DATABASE_URL,
    pool_size=20,
    max_overflow=30,
    pool_pre_ping=True,
    pool_recycle=300,
    echo=settings.DEBUG
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
metadata = MetaData()

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Async database operations
@asynccontextmanager
async def get_async_db():
    conn = await asyncpg.connect(settings.DATABASE_URL)
    try:
        yield conn
    finally:
        await conn.close()

# Create all tables
async def create_tables():
    """Create all database tables"""
    try:
        # Import all models to register them
        from app.models import railway_models, qr_models, user_models, inventory_models, maintenance_models

        # Create tables
        Base.metadata.create_all(bind=engine)
        logging.info("✅ Database tables created successfully")

        # Create indexes
        await create_indexes()

    except Exception as e:
        logging.error(f"❌ Error creating database tables: {e}")
        raise

async def create_indexes():
    """Create database indexes for performance"""
    async with get_async_db() as conn:
        indexes = [
            # Railway indexes
            "CREATE INDEX IF NOT EXISTS idx_tracks_code ON tracks(track_code);",
            "CREATE INDEX IF NOT EXISTS idx_tracks_zone_division ON tracks(zone, division);",
            "CREATE INDEX IF NOT EXISTS idx_components_serial ON railway_components(serial_number);",
            "CREATE INDEX IF NOT EXISTS idx_components_type ON railway_components(component_type);",
            "CREATE INDEX IF NOT EXISTS idx_components_track ON railway_components(track_id);",
            "CREATE INDEX IF NOT EXISTS idx_components_status ON railway_components(status);",

            # QR indexes
            "CREATE INDEX IF NOT EXISTS idx_qr_codes_component ON qr_codes(component_id);",
            "CREATE INDEX IF NOT EXISTS idx_qr_codes_status ON qr_codes(status);",
            "CREATE INDEX IF NOT EXISTS idx_qr_codes_created ON qr_codes(created_at);",

            # User indexes
            "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);",
            "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);",
            "CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);",

            # Inventory indexes
            "CREATE INDEX IF NOT EXISTS idx_inventory_component_type ON inventory_items(component_type);",
            "CREATE INDEX IF NOT EXISTS idx_inventory_location ON inventory_items(location);",
            "CREATE INDEX IF NOT EXISTS idx_inventory_status ON inventory_items(status);",

            # Maintenance indexes
            "CREATE INDEX IF NOT EXISTS idx_maintenance_component ON maintenance_records(component_id);",
            "CREATE INDEX IF NOT EXISTS idx_maintenance_scheduled ON maintenance_records(scheduled_date);",
            "CREATE INDEX IF NOT EXISTS idx_maintenance_status ON maintenance_records(status);",

            # Performance indexes
            "CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);",
            "CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);",
            "CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);",
        ]

        for index_sql in indexes:
            try:
                await conn.execute(index_sql)
            except Exception as e:
                logging.warning(f"Index creation warning: {e}")

        logging.info("✅ Database indexes created successfully")

# Database health check
async def check_database_health():
    """Check database connection health"""
    try:
        async with get_async_db() as conn:
            result = await conn.fetchval("SELECT 1")
            return result == 1
    except Exception as e:
        logging.error(f"Database health check failed: {e}")
        return False

# MongoDB connection (for analytics)
import motor.motor_asyncio

mongodb_client = motor.motor_asyncio.AsyncIOMotorClient(settings.MONGODB_URL)
mongodb_db = mongodb_client[settings.MONGODB_DB]

async def init_mongodb():
    """Initialize MongoDB collections and indexes"""
    try:
        # Create collections
        collections = [
            "qr_analytics",
            "usage_patterns", 
            "performance_metrics",
            "predictive_data",
            "scan_history",
            "realtime_events"
        ]

        for collection_name in collections:
            collection = mongodb_db[collection_name]
            # Create indexes
            if collection_name == "qr_analytics":
                await collection.create_index([("qr_id", 1), ("timestamp", -1)])
                await collection.create_index([("component_type", 1)])
            elif collection_name == "scan_history":
                await collection.create_index([("qr_id", 1), ("scanned_at", -1)])
                await collection.create_index([("user_id", 1)])
            elif collection_name == "realtime_events":
                await collection.create_index([("event_type", 1), ("timestamp", -1)])
                await collection.create_index([("timestamp", -1)], expireAfterSeconds=86400)  # 24 hours TTL

        logging.info("✅ MongoDB collections and indexes created successfully")

    except Exception as e:
        logging.error(f"❌ Error initializing MongoDB: {e}")

# Redis connection (for caching)
import redis.asyncio as redis

redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)

async def init_redis():
    """Initialize Redis connection"""
    try:
        await redis_client.ping()
        logging.info("✅ Redis connection established successfully")
    except Exception as e:
        logging.error(f"❌ Error connecting to Redis: {e}")

# Startup database initialization
async def init_databases():
    """Initialize all databases"""
    await create_tables()
    await init_mongodb()
    await init_redis()
